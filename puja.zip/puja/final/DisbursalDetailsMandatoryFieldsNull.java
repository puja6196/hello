package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalDetailsMandatoryFieldsNull implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	 { 
			 
		
		 List<Map<?,?>> disbursalDetails= MVEL.eval("loan_account.?disbursal_paymnet_details", context, List.class);
		 List<String> logList = new ArrayList<String>();
		 boolean resultFlag = true;
		 if(disbursalDetails!=null)
		 {
		 
			 Iterator<Map<?, ?>> it = disbursalDetails.iterator();
         while (it.hasNext()) 
                    {
               Map<String, String> mapValues = (Map<String, String>) it.next();
		BigDecimal id = new BigDecimal(0);   
		BigDecimal disbursal_BreakupId = new BigDecimal(0);    
		String paymentMode = null;              
		BigDecimal payment_Amount = new BigDecimal(0);           
		Date instrument_Date =  null;
		String ignore_For_Download = null;
		String disbursal_Payment_Status = null;
		BigDecimal receipt_Payment_Id= new BigDecimal(0); 
		BigDecimal dealingbank_Mst_Id =  new BigDecimal(0);
		
		for (Map.Entry entries : mapValues.entrySet()) 
		{
		                       if (("ID").equals(entries.getKey()))
                               id = (BigDecimal) entries.getValue();
                               if (("DISBURSAL_BREAKUPID").equals(entries.getKey()))
    	                       disbursal_BreakupId = (BigDecimal) entries.getValue();
                               if (("PAYMENTMODE").equals(entries.getKey()))
    	                       paymentMode = ((String) entries.getValue().toString());
                               if (("PAYMENT_AMOUNT").equals(entries.getKey()))
    	                       payment_Amount = (BigDecimal) (entries.getValue());
                               if (("INSTRUMENT_DATE").equals(entries.getKey()))
    	                       instrument_Date = (Date) entries.getValue();
                               if (("IGNORE_FOR_DOWNLOAD").equals(entries.getKey()))
    	                       ignore_For_Download = (String) entries.getValue().toString();
                               if (("DISBURSAL_PAYMENT_SATTUS").equals(entries.getKey()))
    	                       disbursal_Payment_Status = (String) entries.getValue().toString();
                               if (("RECEIPT_PAYMENT_ID").equals(entries.getKey()))
    	                       receipt_Payment_Id = (BigDecimal) entries.getValue();
                               if (("DEALINGBANK_MST_ID").equals(entries.getKey()))
    	                       dealingbank_Mst_Id = (BigDecimal) entries.getValue();
		}
       
       if(id==null)
        {
			logList.add("pending "+id);
			resultFlag=false;
		}
		if(disbursal_BreakupId==null)
		{
			logList.add("disbursal_BreakupId is empty for loan id: "+id);
			resultFlag=false;
		}
		if(paymentMode==null)
		{
			logList.add("paymentMode is empty for loan id: "+id);
			resultFlag=false;
		}
		if(payment_Amount==null)
		{
			logList.add("payment_Amount is empty for loan id: "+id);
			resultFlag=false;
		}
		if(instrument_Date==null)
		{
			logList.add("instrument_Date is empty for loan id: "+id);
			resultFlag=false;
		}
		if(ignore_For_Download==null)
		{
			logList.add("ignore_For_Download is empty for loan id: "+id);
			resultFlag=false;
		}
		if(disbursal_Payment_Status==null)
		{
			logList.add("disbursal_Payment_Status is empty for loan id: "+id);
			resultFlag=false;
		}
		if(receipt_Payment_Id==null)
		{
			logList.add("receipt_Payment_Id is empty for loan id: "+id);
			resultFlag=false;
		}
		if(dealingbank_Mst_Id==null)
		{
			logList.add("dealingbank_Mst_Id is empty for loan id: "+id);
			resultFlag=false;
		}
		
      
                
		
		}
         
         if(resultFlag)
         {

             logList.add("None of the record is null");
             
	     	  
         }
		 }else
         {
        	logList.add("disbursalDetails not available") ;
        	resultFlag=false;
         
         }
         
         
         
         
		logger.setLog(logList);
		return resultFlag;
                    
  
     
         }
	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}
	

	}


