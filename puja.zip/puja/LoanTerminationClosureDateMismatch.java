package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanTerminationClosureDateMismatch implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		     JXPathContext ctx = JXPathContext.newContext(context);
		     Boolean resultFlag=true; 
		     List<String> logList = new ArrayList<String>();
		     List<Map<?,?>> loanDetails = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		   
		     if(ctx!=null)
		     {
		     BigDecimal loanAccId = (BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
		     Date closureEgigibleDate = (Date) ctx.getValue("/loan_account/CLOSURE_ELIGIBLE_DATE", Date.class);
		

	         if(loanDetails!=null)
	               {
						
		              Iterator<Map<?, ?>> it = loanDetails.iterator();
		              while (it.hasNext())
							
		                 {
			                  Map<String,String> mapValues = (Map<String, String>) it.next();
			
			                      Date closureEffectiveDate=new Date(0);
			                      BigDecimal loanId=new BigDecimal(0);
			
			                           for (Map.Entry entries : mapValues.entrySet())
			                                {
				                                if(("CLOSURE_EFFECTIVE_DATE").equals(entries.getKey()))
				                                    {
				                        	          closureEffectiveDate=(Date) entries.getValue();
					                                   
				                                     }
				                               
				                                 if(("LOANID").equals(entries.getKey()))
			                                         {
				                        	          loanId=(BigDecimal) entries.getValue();
				
			                                          }
			                                }
		                                         if((loanAccId.compareTo(loanId)==0)&&(closureEgigibleDate!=closureEffectiveDate))
		                                              {
		                                	          resultFlag=false;
		                                	          logList.add("Terminated contracts having closure date mimatch."+loanAccId);
		                                
		                                               }
		                                         if(resultFlag)
		                                         {
		                                        	 
		                                        	 
		                                        	 logList.add("Terminated contracts having closure date match."+loanAccId);
		                                        	 
		                                         }
		                                         
		                                                   
		               }
		     
		          }   
	         else
	              {
	        	 
	        	 logList.add("No record in Loan Details.");
	        	 resultFlag=false;
	        	 
	              }
		  }
		     else
		     {
		    	 logList.add("No record found.");
		    	 resultFlag=false;
		    	 
		     }
		     
	logger.setLog(logList);
    return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
