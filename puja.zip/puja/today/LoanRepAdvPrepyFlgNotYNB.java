package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanRepAdvPrepyFlgNotYNB implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{JXPathContext ctx = JXPathContext.newContext(context);
	  String loanAccStatus=(String) ctx.getValue("/loan_account/STATUS", String.class);
	
		List<String> logList = new ArrayList<String>();
		Boolean resultFlag=true;
		   List<Map<?,?>> loanRepayment  = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		   if(loanRepayment!=null)
           {
				
              Iterator<Map<?, ?>> it = loanRepayment.iterator();
              while (it.hasNext())
					
                 {
	                  Map<String,String> mapValues = (Map<String, String>) it.next();
	
	                 String advncPrepayFlag=null;
	                 BigDecimal loanId=new BigDecimal(0);
	                 
	                      for (Map.Entry entries : mapValues.entrySet())
	                            {
		                          if(("ADVANCE_PREPAY_FLAG").equals(entries.getKey()))
		                                 {
		                        	  advncPrepayFlag=(String) entries.getValue().toString();
			
		                                 }
		                          if(("ID").equals(entries.getKey()))
	                                 {
		                        	  loanId=(BigDecimal) entries.getValue();
		
	                                 }
		                          
	                            }
	                      if((advncPrepayFlag.equalsIgnoreCase("Y"))&&(advncPrepayFlag.equalsIgnoreCase("N"))&&(advncPrepayFlag.equalsIgnoreCase("B"))&&loanAccStatus=="A")
	                      {
	                    	  logList.add(" Data where value for ADVANCE_PREPAY_FLAG is not in ('Y','N','B') in LMS_REPAYSCHEDULE_DTL Table for Loan Id:"+loanId);
	                          resultFlag=false;
	                      
	                      }
	                      }
              if(resultFlag)
              {
            	  
            	  logList.add("No  data available where value for ADVANCE_PREPAY_FLAG is in ('Y','N','B') in LMS_REPAYSCHEDULE_DTL Table .");
              }
              }
		   else
		   {
			   
			   logList.add("No record available in Loan Repayment.");
			   resultFlag=false;
			   
			   
		   }
		   
		   
		   
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) 
	{
	
		return true;
	}

}
