package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanMISMismtchCheqBouncChrg implements RuleExecutor

{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		 JXPathContext ctx = JXPathContext.newContext(context);
	     Boolean resultFlag=true; 
	     BigDecimal advcDtld =new BigDecimal(0);
	     BigDecimal sum=new BigDecimal(0);
	     List<String> logList = new ArrayList<String>();
	     List<Map<?,?>> adviceDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
	     BigDecimal billedBounceAmt= (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/BILLED_BOUNCE_AMT", BigDecimal.class);
	     
         if(adviceDtl!=null)
               {
					
	              Iterator<Map<?, ?>> it = adviceDtl.iterator();
	              while (it.hasNext())
						
	                 {
		                  Map<String,String> mapValues = (Map<String, String>) it.next();
		                     
		                 
		                     BigDecimal chargeAmt=new BigDecimal(0);
		                     BigDecimal chargeCode=new BigDecimal(0);
		                     BigDecimal refChargeCode=new BigDecimal(8);
		                     String status=null;
		                     BigDecimal vapid=new BigDecimal(0);
		
		                           for (Map.Entry entries : mapValues.entrySet())
		                                {
			                                if(("ID").equals(entries.getKey()))
			                                    {
			                                	advcDtld=(BigDecimal) entries.getValue();
				                                   
			                                     }
			                                if(("CHARGE_AMOUNT").equals(entries.getKey()))
		                                    {
			                                	chargeAmt=(BigDecimal) entries.getValue();
			                                   
		                                     }
			                                if(("CHARGECODE").equals(entries.getKey()))
		                                    {
			                                	chargeCode=(BigDecimal) entries.getValue();
			                                   
		                                     }
			                                if(("STATUS").equals(entries.getKey()))
		                                    {
			                                	status=(String) entries.getValue().toString();
			                                   
		                                     }
			                                if(("VAPID").equals(entries.getKey()))
		                                    {
			                                	vapid=(BigDecimal) entries.getValue();
			                                   
		                                     }
		                                }
		                           if((chargeCode.compareTo(refChargeCode)==0)&&(status=="A")&&(vapid.compareTo(new BigDecimal(0))==0))
		                           {
		                        	   
		                           sum=chargeAmt.add(sum);
		                           
		                           
		                           }
		                           
		                }
	              if(billedBounceAmt==null)
	              {
	            	  billedBounceAmt=billedBounceAmt.ZERO;  
	              
	              }
	              if(sum==null)
	              {
	            	  
	            	  sum=sum.ZERO;
	            	  
	              }
	              if(billedBounceAmt.compareTo(sum)!=0)
	              {
	            	  
	            	  logList.add("Loans in Loan MIS where mismatch is found in the cheque bounce charges for Loan Id:"+advcDtld);
	            	  resultFlag=false;
	            	  
	            	  
	              }
               
	              if(resultFlag)
	              {
	            	  
	            	  logList.add("Loans in Loan MIS where match is found in the cheque bounce charges for Loan Id:"+advcDtld);
	            	  
	              }
	              }
         else
         {
        	logList.add("No data available in Advice Detail.") ;
        	resultFlag=false;
        	 
        	 
         }
	              
			                                

		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) 
	{


		return true;
	}

}
