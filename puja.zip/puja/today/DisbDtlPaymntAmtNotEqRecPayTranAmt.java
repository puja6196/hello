package com.nucleus.tools.datasanitizer.lms;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbDtlPaymntAmtNotEqRecPayTranAmt implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		
		


		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) 
	{


		return true;
	}

}
