package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanTerminationClosureDateMismatch implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		  JXPathContext ctx = JXPathContext.newContext(context);
		     Boolean resultFlag=true; 
		     List<String> logList = new ArrayList<String>();
		     List<Map<?,?>> loanDetails = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		     System.out.println("running"+loanDetails);
		     if(ctx!=null)
		     {
		     Long id = (Long) ctx.getValue("/loan_account/ID", Long.class);
		     Date closureEgigibleDate = (Date) ctx.getValue("/loan_account/CLOSURE_ELIGIBLE_DATE", Date.class);
		     System.out.println("eloooo"+closureEgigibleDate);

	         if(loanDetails!=null)
	               {
						
		              Iterator<Map<?, ?>> it = loanDetails.iterator();
		              while (it.hasNext())
							
		                 {
			                  Map<String,String> mapValues = (Map<String, String>) it.next();
			
			                      Date closureEffectiveDate=new Date(0);
			                      Long loanId=new Long(0);
			
			                           for (Map.Entry entries : mapValues.entrySet())
			                                {
				                                if(("CLOSURE_EFFECTIVE_DATE").equals(entries.getKey()))
				                                    {
				                        	          closureEffectiveDate=(Date) entries.getValue();
					                                   
				                                     }
				                               
				                                 if(("LOANID").equals(entries.getKey()))
			                                         {
				                        	          loanId=(Long) entries.getValue();
				
			                                          }
		                                         if((id==loanId)&&(closureEgigibleDate!=closureEffectiveDate))
		                                              {
		                                	          resultFlag=false;
		                                	          logList.add("terminated contracts having closure date mimatch"+id);
		                                
		                                               }
		                                                   logger.setLog(logList);
		                                                   return resultFlag;
		                                     }
		     
		                 }           
		           }
		     }
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
