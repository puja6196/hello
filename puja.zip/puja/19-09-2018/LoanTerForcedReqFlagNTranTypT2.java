package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanTerForcedReqFlagNTranTypT2 implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{

        boolean returnFlag=true;

        List<String> logList = new ArrayList<String>();

        List<Map<?,?>> loanRepayment = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);

       

        if(loanRepayment!=null)
              {
					
	              Iterator<Map<?, ?>> it = loanRepayment.iterator();
	              while (it.hasNext())
						
	                 {
		                  Map<String,String> mapValues = (Map<String, String>) it.next();
		
		                    String forcedReqFlag=null;
		                    String transactionType=null;
		                    
		                      for (Map.Entry entries : mapValues.entrySet())
		                            {
			                          if(("FORCED_REQUESTED_FLAG").equals(entries.getKey()))
			                                 {
			                        	  forcedReqFlag=(String) entries.getValue();
				
			                                 }
			                          if(("TRANSACTION_TYPE").equals(entries.getKey()))
		                                     {
			                        	  transactionType=(String) entries.getValue();
			
		                                     } 
				                       if((forcedReqFlag.equals("N")||forcedReqFlag.equals(null))&&(transactionType.equals("T2")))
				                             {
				                    	   
				                    	   returnFlag=false;
				                    	   logList.add(" Records present in  LMS_TERMINATION_HDR where FORCED_REQUESTED_FLAG is N and FORCED_REQUESTED_FLAG is NULL and TRANSACTION_TYPE is T2.");
				                       		                       
				                             }
				                   }
		                      logger.setLog(logList);
		                      return returnFlag;
	                 }
	              
	              
	              
              }
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
