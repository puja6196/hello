package com.nucleus.tools.datasanitizer.lms;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanDtlNoMISData implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{

		      JXPathContext ctx = JXPathContext.newContext(context);
		      boolean resultFlag = true;
		      List<String> logList = new ArrayList<String>();
		   
		         BigDecimal loanId = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/ID", BigDecimal.class);
		         String loanAccountDetail = (String) ctx.getValue("/loan_account/loan_mis_details/LOAN_ACCOUNT_NO", String.class);
				 BigDecimal tenantIdDetail = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/TENANT_ID", BigDecimal.class);
				 BigDecimal loanMisId = (BigDecimal) ctx.getValue("/loan_account/LOAN_MIS_ID", BigDecimal.class);
				 String loanAccountNo = (String) ctx.getValue("/loan_account/LOAN_ACCOUNT_NO", String.class);
				 BigDecimal tenantId = (BigDecimal) ctx.getValue("/loan_account/TENANT_ID", BigDecimal.class);
				 
				 
				 
		 		
			        if((loanMisId.equals(loanId)&&(loanAccountDetail.equals(loanAccountNo))&&(tenantId.equals(tenantIdDetail))))
		             {
			
			             logList.add(" Loan Account having  corresponding MIS data."+loanId);
			 	         resultFlag=false;
			  
		             }
		      
		            if(resultFlag)
		             {
			  
			             logList.add("Loan Account having no corressponding MIS data.");
			           
			  
		             }
		 
		  
		 
		     
		            
		    logger.setLog(logList);
		    return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
