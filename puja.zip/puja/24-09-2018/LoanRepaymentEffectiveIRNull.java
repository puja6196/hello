package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanRepaymentEffectiveIRNull implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> loanRepayment = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		boolean returnFlag=true;
		List<String> logList = new ArrayList<String>();
		@SuppressWarnings("deprecation")
		Date date=new Date(2015,06,30);
		if(loanRepayment!=null){
			
			Iterator<Map<?, ?>> it = loanRepayment.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				BigDecimal effectiveIntRate = new BigDecimal(0);
				Date dueDate = null;
				Integer loanId=new Integer(0);
				BigDecimal loanIntComp = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()){
					if(("EFFECTIVE_INTEREST_RATE").equals(entries.getKey()))
						effectiveIntRate	 =((BigDecimal)  entries.getValue());
					if(("DUEDATE").equals(entries.getKey()))
						dueDate  = ((Date) entries.getValue());
					if("ID".equals(entries.getKey())){
						loanId= (Integer) entries.getValue();
					}	
				}
				if(effectiveIntRate==null){
					logList.add("Effective Interest Rate is null for Loan Id:"+loanId);
					returnFlag=false;
				}
				
				if(dueDate.compareTo(date)==1){
					logList.add("Due Date is greater than 30-JUN-2018 for Loan Id:"+loanId);
					returnFlag=false;
				}
				
			}

			if(returnFlag){
				logList.add("No data available in Loan Repayment");
			}
		
		}
		else
		{
			
			logList.add("No data available in Loan Repayment");
			returnFlag=false;
			
		}
		
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
