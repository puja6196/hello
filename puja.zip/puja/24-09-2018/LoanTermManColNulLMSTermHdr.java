package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanTermManColNulLMSTermHdr implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{
		JXPathContext ctx = JXPathContext.newContext(context);
		   List<String> logList = new ArrayList<String>();
		   BigDecimal loanId=(BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
		
		   Boolean resultFlag=true;
		   List<Map<?,?>> terminationHdrDtl  = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);

	         if(terminationHdrDtl!=null)
	               {
						
		              Iterator<Map<?, ?>> it = terminationHdrDtl.iterator();
		              while (it.hasNext())
							
		                 {
			                  Map<String,String> mapValues = (Map<String, String>) it.next();
			
			                  BigDecimal id=new BigDecimal(0);
			                  String status=null;
			                      for (Map.Entry entries : mapValues.entrySet())
			                            {
				                          if(("ID").equals(entries.getKey()))
				                                 {
				                        	  id=(BigDecimal) entries.getValue();
					
				                                 }
				                          if(("STATUS").equals(entries.getKey()))
			                                 {
				                        	  status=(String) entries.getValue().toString();
				
			                                 }
			                            }
			                      if(((loanId.compareTo(null))==0)&&((id.compareTo(loanId))==0)&&(status=="A"))
			                      {
			                    	  
			                      logList.add("Data where mandatory columns are null in  LMS_TERMINATION_HDR table for Loan Id:"+loanId);
			                      resultFlag=false;
			                      
			                      
			                      }
		                 }
			                      if(resultFlag)
			                      {
			                    	  
			                    	  logList.add("Data where mandatory columns are not null in  LMS_TERMINATION_HDR table for Loan Id:"+loanId);
			                      
			                      
			                      
			                      }
			                      
	               }
		              else
		              {
		              logList.add("No record available in termination Detail");
		              }
	         
	         logger.setLog(logList);
	         return resultFlag;
	
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
