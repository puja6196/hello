package com.nucleus.tools.datasanitizer.lms.future.prog;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class MisDtlMisMatchInBilledTdsAmt implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		BigDecimal adviceDtlLoanId = new BigDecimal(0);
		BigDecimal misLoanId = new BigDecimal(0);
		BigDecimal tdsAmt = new BigDecimal(0);
		BigDecimal sumTdsAmt = new BigDecimal(0);
		BigDecimal vapId = new BigDecimal(0);
		String adviceStatus = null;
		boolean resultFlag = true;
		List<Map<?, ?>> adviceDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		JXPathContext ctx = JXPathContext.newContext(context);
		try {
			misLoanId = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/LOANID", BigDecimal.class);
		} catch (Exception e) {
			logList.add("Exception occured while retrieving data from Loan Account and Loan Mis Details");
		}
		if (adviceDtl != null) {
			Iterator<Map<?, ?>> it = adviceDtl.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					try {
						if (("TDS_AMT").equals(entries.getKey()))
							tdsAmt = (BigDecimal) entries.getValue();
						if (("LOANID").equals(entries.getKey()))
							adviceDtlLoanId = (BigDecimal) entries.getValue();
						if (("STATUS").equals(entries.getKey()))
							adviceStatus = (String) entries.getValue();
						if (("VAPID").equals(entries.getKey()))
							vapId = (BigDecimal) entries.getValue();
						if (vapId == null)
							vapId = BigDecimal.ZERO;
					} catch (Exception e) {
						logList.add("Exception occured while retrieving data from Advice Details");
					}
				}
				if (tdsAmt == null)
					tdsAmt = BigDecimal.ZERO;
				if (sumTdsAmt == null)
					sumTdsAmt = BigDecimal.ZERO;
				if (vapId.compareTo(new BigDecimal(0)) == 0) {
					if ((adviceDtlLoanId.compareTo(misLoanId) == 0) && ("A".equals(adviceStatus))) {
						sumTdsAmt = sumTdsAmt.add(tdsAmt);
						logList.add("Loan Mis Details having mismatch in Billed Tds Amount");
						resultFlag = false;
					}
				}

			}
		} else {
			logList.add("No data available in Advice Details");
			resultFlag = false;
		}

		if (resultFlag)
			logList.add("Loan Mis details having No mismatch in Billed Tds Amount");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject logger) {
		// TODO Auto-generated method stub
		return true;
	}

}
