package com.nucleus.tools.datasanitizer.lms.future.prog;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalBrkupNotInDisbursalDtl implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> distbursalBreakupDetails = MVEL
				.eval("loan_account.?disbursal_details.?disbursal_details_breakup", context, List.class);
		List<String> logList = new ArrayList<String>();
		BigDecimal disbursalId = new BigDecimal(0);
		BigDecimal disbursalBrkUpId = new BigDecimal(0);
		boolean resultFlag = true;
		JXPathContext ctx = JXPathContext.newContext(context);
		try {
			disbursalId = (BigDecimal) ctx.getValue("/loan_account/disbursal_details/ID", BigDecimal.class);
		} catch (Exception e) {
			logList.add("Exception occured while retrieving data from Disbursal Details");
		}
		if(distbursalBreakupDetails!=null)
		{
			Iterator<Map<?, ?>> it = distbursalBreakupDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					try {
					
						if (("DISBURSAL_ID").equals(entries.getKey()))
							disbursalBrkUpId = (BigDecimal) entries.getValue();
					} catch (Exception e) {
						logList.add("Exception occured while Retrieving data from DisbursalBreakUp Detail");
					}
				}
				if(disbursalBrkUpId.compareTo(disbursalId)==0){
				//Do nothing	
				}
				else{
					logList.add("Disbursal BreakUp Details does not exist in Disbursal details for for Disbursal Id:"+disbursalBrkUpId);
					resultFlag=false;
				}
			}
		}
		else{
			logList.add("No data available in Disbursal BreakUp Details");
			resultFlag=false;
		}
		if (resultFlag)
			logList.add("Disbursal Details does exist in DisbursalBreakup Details");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
