package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RecordsInLmsTerminationWithRequestedFlagAndPenaltyCharge implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> loanTermination = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		String forcedRequestedFlag = (String) ctx.getValue("/loan_account/termination_hdr_details/FORCED_REQUESTED_FLAG", String.class);
		String penaltyChargeNature = (String) ctx.getValue("/loan_account/termination_hdr_details/PENALTY_CHARGE_NATURE", String.class);
		List<String> logList = new ArrayList<String>();
		if(loanTermination!=null){
			Iterator<Map<?, ?>> it = loanTermination.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();

				for (Map.Entry entries : mapValues.entrySet()){
					if(("Y".equals(forcedRequestedFlag))&&("R".equals(penaltyChargeNature))){
						logList.add("Number of records present in  LMS_TERMINATION_HDR where FORCED_REQUESTED_FLAG is Y and PENALTY_CHARGE_NATURE is R");
						logger.setLog(logList);
						return true;
					}
				}
		}
		
	}return false;
	}
	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
