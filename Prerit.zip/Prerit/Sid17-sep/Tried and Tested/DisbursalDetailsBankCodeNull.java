package com.nucleus.tools.datasanitizer.lms;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalDetailsBankCodeNull implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<String>();
		String paymentMode = (String) ctx.getValue("/loan_account/disbursal_paymnet_details ", String.class);
		Long dealingbank_mst_id = (Long) ctx.getValue("/loan_account/disbursal_paymnet_details ", Long.class);
		  List<Map<?,?>> disbursalPaymentDetail = MVEL.eval("loan_account.?disbursal_paymnet_details", context, List.class);
		 Long Id = (Long) ctx.getValue("/loan_account/ID", Long.class);
	      
	  if(disbursalPaymentDetail!=null){
		    if(paymentMode!="2670"&&paymentMode!="2669"){
		    	  if(dealingbank_mst_id==null)
		    		  logList.add("Number of records in LMS_DISBURSAL_PAYMENT_DTL table having paymentmode not in cheque and draft and dealing_bank_code is null where Id is ="+Id);
		    	  logger.setLog(logList);
		    		  return true;
		    		  
		      }
	  }
	    logList.add("Number of records in LMS_DISBURSAL_PAYMENT_DTL table having paymentmode in cheque or draft or dealing_bank_code is null, where Id is ="+Id);	  
	    logger.setLog(logList);
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
