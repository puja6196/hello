package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RecordsInLoanAdditionalInfoWithNoCorrespondingData implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsLoanAdditionalInfoDetails = MVEL.eval("loan_account.?loan_additional_info", context, List.class);
	//	List<Map<?,?>> lmsLoanAccountDetails = MVEL.eval("loan_account.?", context, List.class);
		
		JXPathContext ctx = JXPathContext.newContext(context);
		Long lmsLoanAdditionalInfoDtlId = (Long) ctx.getValue("/loan_account/loan_additional_info/ID", Long.class);
		Long lmsLoanAccountDtlId = (Long) ctx.getValue("/loan_account/ID", Long.class);
		Long lmsLoanAdditionalInfoDtlTenantId=(Long)ctx.getValue("/loan_account/loan_additional_info/TENANT_ID",Long.class);
	
		Long lmsLoanAccountDtlTenantId = (Long) ctx.getValue("/loan_account//TENANT_ID", Long.class);
		List<String> logList = new ArrayList<String>();
		if(lmsLoanAdditionalInfoDetails!=null){
			
			if(lmsLoanAdditionalInfoDtlId==lmsLoanAccountDtlId&&lmsLoanAdditionalInfoDtlTenantId==lmsLoanAccountDtlTenantId){
				logList.add("Count of Records in Loan Additional Info having  corresponding loan data.");
				 logger.setLog(logList);
				return false;
			}
		}
		logList.add("Count of Records in Loan Additional Info having no corresponding loan data.");
		 logger.setLog(logList);
		return true;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
