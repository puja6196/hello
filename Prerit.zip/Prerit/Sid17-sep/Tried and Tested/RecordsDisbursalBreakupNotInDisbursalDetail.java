package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RecordsDisbursalBreakupNotInDisbursalDetail implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsDistbursalBreakupDetails = MVEL.eval("loan_account.?disbursal_details_breakup", context, List.class);
		List<Map<?,?>> lmsDistbursalDetails = MVEL.eval("loan_account.?disbursal_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		JXPathContext ctx = JXPathContext.newContext(context);
		Long disbBreakupDtlId = (Long) ctx.getValue("/loan_account/disbursal_details/disbursal_details_breakup/ID", Long.class);
		Long lmsDisbursalDtlId = (Long) ctx.getValue("/loan_account/disbursal_details/ID", Long.class);
		Long loanId = (Long) ctx.getValue("/loan_account/ID", Long.class);
		if(lmsDistbursalBreakupDetails != null&&lmsDistbursalDetails!=null){
		
		Iterator<Map<?, ?>> it = lmsDistbursalBreakupDetails.iterator();
		while (it.hasNext()){
			Map<String,String> mapValues = (Map<String, String>) it.next();

			for (Map.Entry entries : mapValues.entrySet()){
			if(disbBreakupDtlId!=lmsDisbursalDtlId)	{
				logList.add("List of Records from LMS_DISBURSAL_BREAKUP_DTL where data does not exist in LMS_DISBURSAL_DTL, And Loan Id is="+loanId);
				logger.setLog(logList);
				return true;
			}
			}
			}
		}
	    logList.add("List of Records from LMS_DISBURSAL_BREAKUP_DTL where data does  exist in LMS_DISBURSAL_DTL, And Loan Id is="+loanId);
	    logger.setLog(logList);
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
