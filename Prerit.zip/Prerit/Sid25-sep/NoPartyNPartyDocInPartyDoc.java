package com.nucleus.tools.datasanitizer.lms.future.prog;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class NoPartyNPartyDocInPartyDoc implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
	boolean resultFlag=true;
	List<Map<?,?>> partyDocument = MVEL.eval("loan_account.?cas_party_documents", context, List.class);
	BigDecimal partyDocuments=new BigDecimal(0);
	BigDecimal partyDocId=new BigDecimal(0);
	BigDecimal party=new BigDecimal(0);
	List<String> logList = new ArrayList<String>();
	if(partyDocument!=null){
	Iterator<Map<?, ?>> it = partyDocument.iterator();
	while (it.hasNext()){
		Map<String,String> mapValues = (Map<String, String>) it.next();
		for (Map.Entry entries : mapValues.entrySet()){
		try{
			if (("PARTY_DOCUMENTS").equals(entries.getKey()))
				partyDocuments = (BigDecimal)entries.getValue();
			if (("PARTY").equals(entries.getKey()))
				party =(BigDecimal) entries.getValue();
			if (("ID").equals(entries.getKey()))
				partyDocId = (BigDecimal)entries.getValue();
		}
		catch(Exception e){
			logList.add("Exception occured while retrieving data from Party Document");
		}
		}
		if(party==null||partyDocuments==null){
			logList.add("party and party document are null in Party Documents for Id :"+partyDocId);
			resultFlag=false;
		}
	}
	}
	else{
		logList.add("No data available in Party Document");
		resultFlag=false;
	}
	if(resultFlag)
		logList.add("party and party document are not null in Party Documents for Id :"+partyDocId);
	logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
