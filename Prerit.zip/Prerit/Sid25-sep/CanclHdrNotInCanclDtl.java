package com.nucleus.tools.datasanitizer.lms.future.prog;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class CanclHdrNotInCanclDtl implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> canclHdrDtl = MVEL.eval("loan_account.?canc_hdr_dtls", context, List.class);
		List<Map<?,?>> canclDtl = MVEL.eval("loan_account.?cancellation_dtl_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		BigDecimal canclHdrId=new BigDecimal(0);
		BigDecimal canclRefId=new BigDecimal(0);
		boolean resultFlag=true;
				Iterator<Map<?, ?>> it = canclDtl.iterator();
				while (it.hasNext()) {
					Map<String, String> mapValues = (Map<String, String>) it.next();
					for (Map.Entry entries : mapValues.entrySet()) {
						try{
							if(("CANCELLATION_REF_ID").equals(entries.getKey()))
								canclRefId=(BigDecimal)entries.getValue();
							
							if(("canc_hdr_dtls").equals(entries.getKey()))
								canclHdrDtl=(List<Map<?, ?>>) entries.getValue();
							Iterator<Map<?, ?>> itIn = canclHdrDtl.iterator();
							while (itIn.hasNext()) {
								Map<String, String> mapValue = (Map<String, String>) itIn.next();
								for (Map.Entry entry : mapValue.entrySet()){
								if(("ID").equals(entry.getKey()))
									canclHdrId=(BigDecimal)entry.getValue();
								}	
							}
						}
						catch(Exception e){
							logList.add("Exception occured while retrieving data from Cancellation Hdr and Cancellation Details");
						}
					}
					  if(canclHdrId.compareTo(canclRefId)==0){
					//do nothing
						}
						else{
							logList.add("Lms Cancellation Hdr not In Lms Cancellation Dtl for Cancellation Ref Id:"+canclRefId);
							resultFlag=false;
						}
     
					
				}
				
				
	if(resultFlag)
		logList.add("Lms Cancellation Hdr Available In Lms Cancellation Details for Cancellation Ref Id: "+canclRefId);
    logger.setLog(logList);	
	return resultFlag;
	}
		
	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
