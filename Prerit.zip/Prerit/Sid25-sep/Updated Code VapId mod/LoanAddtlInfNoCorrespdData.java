package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.JXPathContext;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAddtlInfNoCorrespdData implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal LnAdditionalInfoDtlId = new BigDecimal(0);
		BigDecimal LoanAcctAddInfoId = new BigDecimal(0);
		BigDecimal LnAdditionalInfoTenantId = new BigDecimal(0);
		BigDecimal LnAcctDtlTenantId = new BigDecimal(0);
		BigDecimal vapId = new BigDecimal(0);
		BigDecimal vapId0 = new BigDecimal(0);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		try {
			LnAdditionalInfoDtlId = (BigDecimal) ctx.getValue("/loan_account/loan_additional_info/ID",
					BigDecimal.class);
			LoanAcctAddInfoId = (BigDecimal) ctx.getValue("/loan_account/LOAN_ADDITIONAL_INFO_ID", BigDecimal.class);
			vapId = (BigDecimal) ctx.getValue("/loan_account/VAPID", BigDecimal.class);
			LnAdditionalInfoTenantId = (BigDecimal) ctx.getValue("/loan_account/loan_additional_info/TENANT_ID",
					BigDecimal.class);
			LnAcctDtlTenantId = (BigDecimal) ctx.getValue("/loan_account/TENANT_ID", BigDecimal.class);
		} catch (Exception e) {

		}

		if (vapId.compareTo(vapId0) == 0) {
			if ((LnAdditionalInfoDtlId.compareTo(LoanAcctAddInfoId) == 0)
					&& (LnAcctDtlTenantId.compareTo(LnAdditionalInfoTenantId) == 0)) {
				// do nothing
			} else {
				logList.add(" Record in Loan Additional Info have no corresponding loan data.");
				resultFlag = false;
			}
		}
		if (resultFlag)
			logList.add(" Record in Loan Additional Info having  corresponding loan data.");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
