package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TerminationReqFlagYAndPenChrgR implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> loanTermination = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		String forcedRequestedFlag = null;
		String penaltyChargeNature = null;
		BigDecimal terminationId = new BigDecimal(0);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if (loanTermination != null) {
			Iterator<Map<?, ?>> it = loanTermination.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {

					if (("FORCED_REQUESTED_FLAG").equals(entries.getKey()))
						forcedRequestedFlag = (String) entries.getValue();
					if (("PENALTY_CHARGE_NATURE").equals(entries.getKey()))
						penaltyChargeNature = (String) entries.getValue();
					if (("ID").equals(entries.getKey()))
						terminationId = (BigDecimal) entries.getValue();
				}
				if (("Y".equalsIgnoreCase(forcedRequestedFlag) && ("R".equals(penaltyChargeNature)))) {
					logList.add("Forced requested flag is Y and Penalty charge nature is R for termination header id : "
							+ terminationId);
					resultFlag = false;
				}

			}
		} else {
			logList.add("Termination Header data not available.");
			resultFlag = false;
		}

		if (resultFlag)
			logList.add("No cases exists where Forced requested flag is Y and Penalty charge nature is R");

		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
