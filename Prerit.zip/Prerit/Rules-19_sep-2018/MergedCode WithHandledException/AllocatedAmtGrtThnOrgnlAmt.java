package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class AllocatedAmtGrtThnOrgnlAmt implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> lmsRecievablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal allocatedAmt = new BigDecimal(0);
		BigDecimal originalAmt = new BigDecimal(0);
		BigDecimal adviceId = new BigDecimal(0);
		String status = null;
		boolean resultFlag = true;
		List<String> logList = new ArrayList<String>();
		if (lmsRecievablePayableDtl != null) {
			status = (String) ctx.getValue("/loan_account/STATUS", String.class);
			Iterator<Map<?, ?>> it = lmsRecievablePayableDtl.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {

				try{
					if (("ID").equals(entries.getKey()))
						adviceId = (BigDecimal) entries.getValue();
					if (("ALLOCATEDAMT").equals(entries.getKey()))
						allocatedAmt = (BigDecimal) entries.getValue();
					if (("ORIGINALAMT").equals(entries.getKey()))
						originalAmt = (BigDecimal) entries.getValue();

					if (allocatedAmt == null) {
						allocatedAmt = BigDecimal.valueOf(0);
					}
					if (originalAmt == null) {
						originalAmt = BigDecimal.valueOf(0);
					}
				}
				catch(Exception e){
					logList.add("Missing Fields in Advice Details causing Nullpointer Exception");
				}

				}

				if ("A".equals(status)) {
					if (allocatedAmt.compareTo(originalAmt) == 1) {
						logList.add("Allocated amount is greater than Original Amount for Advice Id : " + adviceId);
						resultFlag = false;
					}
				}

			}

		} else {
			logList.add("Advice data is not available.");
			resultFlag = false;
		}

		if (resultFlag)
			logList.add("Allocated amount is not greater than Original Amount.");

		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
