package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFieldsPaymentDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		List<Map<?, ?>> paymentDetails = MVEL.eval("loan_account.?payment_details", context, List.class);
		if (paymentDetails != null) {
			Iterator<Map<?, ?>> it = paymentDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				String party_ref_no = null ;
				BigDecimal party_type = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("PARTY_REF_NO").equals(entries.getKey()))
						party_ref_no = (String)entries.getValue();
					
					if (("PARTY_TYPE").equals(entries.getKey()))
						party_type = (BigDecimal)entries.getValue();
				}
					if (party_ref_no != null) {
						if (party_type == null) {
							logList.add("Party Type in Payment details Is null while Party Ref# is not null. Part Ref# : "+party_ref_no);
							returnFlag = false;
						}

					} 
				
				
				
				

			}
			if (returnFlag) {
				logList.add("Party Type in Payment details Is not null where Party Ref# is not null.");
			}
		} else {
			returnFlag = false;
			logList.add("Payment Details are not available.");
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
