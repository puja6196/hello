package com.nucleus.tools.datasanitizer.lms;



import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalDetailsBankCodeNull implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<String>();
		BigDecimal paymentMode = new BigDecimal(0);
	BigDecimal dealingbank_mst_id = new BigDecimal(0);
	BigDecimal disbPaymentId = new BigDecimal(0);
	List<Map<?,?>> disbursalPaymentDetail = MVEL.eval("loan_account.?disbursal_paymnet_details", context, List.class);
	
		BigDecimal payMode2670 = new BigDecimal(2670);
		BigDecimal payMode2669 = new BigDecimal(2669);
	
	      boolean resultFlag=true;
	  if(disbursalPaymentDetail!=null){

		  Iterator<Map<?, ?>> it =disbursalPaymentDetail.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()){
					 if (("PAYMENTMODE").equals(entries.getKey()))
						 paymentMode = (BigDecimal)entries.getValue();
                   if (("DEALINGBANK_MST_ID").equals(entries.getKey()))
                	   dealingbank_mst_id = ((BigDecimal) entries.getValue());
                   if (("ID").equals(entries.getKey()))
                	   disbPaymentId = ((BigDecimal) entries.getValue());
                   
				}
                  
				if(  (paymentMode.compareTo(payMode2670)== 0 || paymentMode.compareTo(payMode2669)==0 ) && dealingbank_mst_id == null){
					
					logList.add("Payment mode is not cheque or draft while dealingbank mst id is null for disbursal payment Id : "+disbPaymentId);
					resultFlag=false;
				}
				}
	  }else{
                 
     		    		  
     		    		
	logList.add("Disbursal payment details are not available.");
	resultFlag=false;
	  }
	  
	  logList.add("dealingbank mst id is not null for disbursal payment details where Payment mode is not cheque or draft");
	    logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
