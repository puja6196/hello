package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TerminForcdFlgYAndTxTypT1 implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> loanTerminationHdr = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		String forcedRequestedFlag = null;
		String transactionType = null;
		BigDecimal terminationHeaderId = new BigDecimal(0);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if (loanTerminationHdr != null) {
			Iterator<Map<?, ?>> it = loanTerminationHdr.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {

					if (("FORCED_REQUESTED_FLAG").equals(entries.getKey()))
						forcedRequestedFlag = entries.getValue().toString();
					if (("TRANSACTION_TYPE").equals(entries.getKey()))
						transactionType = entries.getValue().toString();
					if (("ID").equals(entries.getKey()))
						terminationHeaderId = (BigDecimal) entries.getValue();
				}
				if (("Y".equals(forcedRequestedFlag)) && ("T1".equals(transactionType))) {
					logList.add("ForcedRequestedFlag is Y and transaction Type is T1 for Termination Header Id : "
							+ terminationHeaderId);
					resultFlag = false;
				}

			}
		}

		else {
			logList.add("Termination Header data is not available.");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add("Termination Header data is not having ForcedRequestedFlag as Y for transaction Type T1.");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
