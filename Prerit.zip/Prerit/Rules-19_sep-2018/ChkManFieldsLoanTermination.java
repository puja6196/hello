package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFieldsLoanTermination implements RuleExecutor {

	public boolean execute(RootObject context, Logger logger) {
	
		List<Map<?, ?>> terminationDetails = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if (terminationDetails != null) {
			Iterator<Map<?, ?>> it = terminationDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				BigDecimal chargecode_mst_id = new BigDecimal(0);
				BigDecimal loanid = new BigDecimal(0);
				BigDecimal chargecode = new BigDecimal(0);
				BigDecimal receivable_payable_flag = new BigDecimal(0);
				BigDecimal terminationId =new BigDecimal(0);;
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("CHARGECODE_MST_ID").equals(entries.getKey()))
						chargecode_mst_id = ((BigDecimal) entries.getValue());
					if (("LOANID").equals(entries.getKey()))
						loanid = ((BigDecimal) entries.getValue());
					if (("CHARGECODE").equals(entries.getKey()))
						chargecode = ((BigDecimal) entries.getValue());
					if (("RECEIVABLE_PAYABLE_FLAG").equals(entries.getKey()))
						receivable_payable_flag = ((BigDecimal) entries.getValue());
					if (("ID").equals(entries.getKey()))
						terminationId = ((BigDecimal) entries.getValue());
					
				}
				
					if (chargecode_mst_id == null) {
						logList.add("CHARGECODE_MST_ID in Loan Termination is null for termination id : "+terminationId);
						returnFlag = false;
					}
					if (loanid == null) {
						logList.add("LOANID in Loan Termination is null for termination id : "+terminationId);
						returnFlag = false;
					}
					if (chargecode == null) {
						logList.add("CHARGECODE in Loan Termination is null for termination id : "+terminationId);
						returnFlag = false;
					}
					if (receivable_payable_flag == null) {
						logList.add("RECEIVABLE_PAYABLE_FLAG in Loan Termination is null for termination id : "+terminationId);
						returnFlag = false;
					}
				

			}
			if (returnFlag) {
				logList.add(
						"CHARGECODE_MST_ID, LOANID, CHARGECODE, RECEIVABLE_PAYABLE_FLAG in Loan Termination Dtl are not null.");
			}
		} else {
			returnFlag = false;
			logList.add("Loan Termination Details are not available.");

		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
