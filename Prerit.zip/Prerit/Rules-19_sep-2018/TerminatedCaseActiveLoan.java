package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TerminatedCaseActiveLoan implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsTerminationHdr = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		String lmsTerminationHdrMcStatus=null;
		String lmsLoanAccountDtlStatus=null;			 
	
		List<String> logList = new ArrayList<String>();
		boolean resultFlag=true;
		if(lmsTerminationHdr!=null){
			lmsLoanAccountDtlStatus=(String)ctx.getValue("/loan_account/STATUS",String.class);
			Iterator<Map<?, ?>> it = lmsTerminationHdr.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()){
						if (("MC_STATUS").equals(entries.getKey()))
							lmsTerminationHdrMcStatus =(String) entries.getValue();
				}
				
				if("A".equals(lmsTerminationHdrMcStatus) && "A".equals(lmsLoanAccountDtlStatus)){
					logList.add("Loan is Active while data is available in Termination with MC_STATUS 'A'.");
					resultFlag=false;
					break;
				}
				
				
				}
		}else {
		logList.add("Termination data is not available.");
		resultFlag= false;
	}  
		
		if(resultFlag)
			logList.add("Data available in termination corresponds to Closed Loan.");
		
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
