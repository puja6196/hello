package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RecordsWithPrincipalComponentLessThanRecievedPrincipalComponent implements RuleExecutor  {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsRecievablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		Long lmsRecievablePayableDtlLoanId = (long)0;
		Long lmsLoanAccountDtlId = (long)0;
		Long principalComponent=(long)0;
		Long principalCompRecieved = (long) 0;
		Long loanId = (long)0;
		String status=null;
		boolean resultFlag=false;
	try{
		 lmsRecievablePayableDtlLoanId = (Long) ctx.getValue("/loan_account/LMS_RECEIVABLEPAYABLE_DTL/LOANID", Long.class);
		 lmsLoanAccountDtlId = (Long) ctx.getValue("/loan_account/LMS_LOANACCOUNT_DTL/ID", Long.class);
		 principalComponent=(Long)ctx.getValue("/loan_account/LMS_RECEIVABLEPAYABLE_DTL/PRINCIPAL_COMPONENT",Long.class);
		 principalCompRecieved = (Long) ctx.getValue("/loan_account/LMS_RECEIVABLEPAYABLE_DTL/PRINCOMP_RECEIVED", Long.class);
		 loanId = (Long) ctx.getValue("/loan_account/ID", Long.class);
		 status=(String) ctx.getValue("/loan_account/LMS_LOANACCOUNT_DTL/STATUS",String.class);
	}
	catch(Exception e){
		
	}
		List<String> logList = new ArrayList<String>();
		int valReplacement=0;
		if(lmsRecievablePayableDtl!=null){
			if(principalComponent==null){
				principalComponent=(long) valReplacement;
			}
			if(principalCompRecieved==null){
				principalCompRecieved=(long) valReplacement;
			}
			if(principalCompRecieved>principalComponent){
				if((lmsRecievablePayableDtlLoanId==lmsLoanAccountDtlId)&&("A".equals(status))){
					logList.add("Number of records where Principal Component is less than Received Principal Component where LoanId is="+loanId);
					logger.setLog(logList);
					resultFlag= true;
				}
			}
		}else{
		logList.add("Number of records where Principal Component is less than Received Principal Component where Loan Id is="+loanId);
		logger.setLog(logList);
		resultFlag= false;
	}return resultFlag;
	}
	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
