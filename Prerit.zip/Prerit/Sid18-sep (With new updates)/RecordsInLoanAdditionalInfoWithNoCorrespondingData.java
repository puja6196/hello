package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RecordsInLoanAdditionalInfoWithNoCorrespondingData implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsLoanAdditionalInfoDetails = MVEL.eval("loan_account.?loan_additional_info", context, List.class);		
		JXPathContext ctx = JXPathContext.newContext(context);
		Long lmsLoanAdditionalInfoDtlId = (long) 0;
		Long lmsLoanAccountDtlId = (long) 0;
		Long lmsLoanAdditionalInfoDtlTenantId=(long)0;
		Long lmsLoanAccountDtlTenantId = (long)0;
	try{
		 lmsLoanAdditionalInfoDtlId = (Long) ctx.getValue("/loan_account/loan_additional_info/ID", Long.class);
		 lmsLoanAccountDtlId = (Long) ctx.getValue("/loan_account/ID", Long.class);
		 lmsLoanAdditionalInfoDtlTenantId=(Long)ctx.getValue("/loan_account/loan_additional_info/TENANT_ID",Long.class);
		 lmsLoanAccountDtlTenantId = (Long) ctx.getValue("/loan_account/TENANT_ID", Long.class);
	}
	catch(Exception e){
		
	}
		List<String> logList = new ArrayList<String>();
		boolean resultFlag=false;
		if(lmsLoanAdditionalInfoDetails!=null){
			if(lmsLoanAdditionalInfoDtlId==lmsLoanAccountDtlId&&lmsLoanAdditionalInfoDtlTenantId==lmsLoanAccountDtlTenantId){
				logList.add(" Record in Loan Additional Info having  corresponding loan data.");
				 logger.setLog(logList);
				resultFlag= false;
			}
		}else{
		logList.add(" Record in Loan Additional Info having no corresponding loan data.");
		 logger.setLog(logList);
		resultFlag =true;
	} return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
