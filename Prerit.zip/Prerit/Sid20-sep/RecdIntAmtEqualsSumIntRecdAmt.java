package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RecdIntAmtEqualsSumIntRecdAmt implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> recievablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		JXPathContext ctx = JXPathContext.newContext(context);
		boolean resultFlag=false;
		Long recordIntAmt = (Long) ctx.getValue("/loan_account/loan_mis_details/RECD_INT_AMT", Long.class);
		Long misLoanId = (Long) ctx.getValue("/loan_account/loan_mis_details/LOANID", Long.class);
		BigDecimal chargeCode=new BigDecimal(0);
		String status=null;
		BigDecimal vapId=new BigDecimal(0);
		BigDecimal adviceLoanId=new BigDecimal(0);
		BigDecimal valReplacement=new BigDecimal(0);
		BigDecimal intCompRecieved=new BigDecimal(0);
		if(recievablePayableDtl!=null){
			Iterator<Map<?, ?>> it = recievablePayableDtl.iterator();
            while (it.hasNext()) {
            	
                    Map<String, String> mapValues = (Map<String, String>) it.next();
                    for (Map.Entry entries : mapValues.entrySet()){
                    	if (("LOANID").equals(entries.getKey()))
                    		adviceLoanId = (BigDecimal)entries.getValue();
						if (("CHARGECODE").equals(entries.getKey()))
							chargeCode =(BigDecimal) entries.getValue();
						if (("VAPID").equals(entries.getKey()))
							vapId = (BigDecimal) entries.getValue();
						if (("STATUS").equals(entries.getKey()))
							status = (String) entries.getValue();
						if (("INTCOMP_RECEIVED").equals(entries.getKey()))
							intCompRecieved = (BigDecimal)entries.getValue();
						if(intCompRecieved==null)
							intCompRecieved=valReplacement;
						if((misLoanId.equals(adviceLoanId))&&("A".equals(status))&&(chargeCode.equals(9))&&(vapId.equals(0))){
							intCompRecieved=intCompRecieved.add(intCompRecieved);
						}
						
                   
                    }
            
		}
            if(recordIntAmt.equals(intCompRecieved)){
				logList.add("Records having Recd_Int_Amount equals to sum of int_ComponentsRecieved");
				resultFlag=true;
			}
            else{
            	logList.add("Records having Recd_Int_Amount equals not to sum of int_ComponentsRecieved");
            	resultFlag=false;
            }	
	}
		else{
			logList.add("No records found");
			resultFlag=false;
		}
		logger.setLog(logList);
		return resultFlag;
	}
	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
