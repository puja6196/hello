package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LnActSectzDealIdNullAndSectzFlgY implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		String securitizedFlag = null;
		Long securitizedDealId=(long)0;
		List<String> logList = new ArrayList<String>();
	    boolean resultFlag=false; 
		
		try{
			securitizedFlag = (String) ctx.getValue("/loan_account/SECURITIZED_FLAG", String.class);
			 securitizedDealId = (Long) ctx.getValue("/loan_account/SECURITIZED_DEALID", Long.class);
		}
		catch(Exception e){
			
		}
		if((securitizedDealId==null)&&("Y".equals(securitizedFlag))){
			logList.add("Records in LMS loan Account where securitized Deal Id is null and Flag is 'Y' ");
			resultFlag=true;
		}
		else{
			logList.add("Records in LMS loan Account where securitized Deal Id is not null or Flag is not 'Y' ");
			resultFlag=false;
		
		}
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject logger) {
		// TODO Auto-generated method stub
		return true;
	}

}
