package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class MandtryColAreNullInTerminHDR implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsTerminationHdr = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		Long lmsLoanAccountDtlId=(long)0;
		Long terminationHdrLoanId=(long)0;
		Long loanId=(long)0;
		String lmsTerminationHdrMcStatus=null;
		String lmsLoanAccountDtlStatus=null;
		try {
			 lmsLoanAccountDtlId=(Long)ctx.getValue("/loan_account/ID",Long.class);
			 loanId=(Long)ctx.getValue("/loan_account/ID",Long.class);
			 lmsLoanAccountDtlStatus=(String)ctx.getValue("/loan_account/STATUS",String.class);
		}
		catch(Exception e){
			
		}
		List<String> logList = new ArrayList<String>();
		boolean resultFlag=false;
		if(lmsTerminationHdr!=null){
			Iterator<Map<?, ?>> it = lmsTerminationHdr.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()){
					try {
						if (("LOANID").equals(entries.getKey()))
							terminationHdrLoanId = (Long) entries.getValue();
					} catch (NullPointerException e) {
						
					}
					if(terminationHdrLoanId==null){
						if((terminationHdrLoanId==lmsLoanAccountDtlId)&&("A".equals(lmsLoanAccountDtlStatus))){
							logList.add("Records with Blank mandatory fields or Records with Loan Id And Id is equal to null where loanId is:"+terminationHdrLoanId);
							resultFlag= true;
						}
						else{
							logList.add("Records with Loan Id And Id is equal not to null where loanId is:"+terminationHdrLoanId);
							resultFlag=false;
						}
					}
				}
		}
		}else {
		logList.add("no record found");
		resultFlag= false;
	}
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
