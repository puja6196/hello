package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class AllocatedAmtGrtThnOrgnlAmt implements RuleExecutor  {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsRecievablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		Long lmsRecievablePayableDtlLoanId = (long) 0;
		Long lmsLoanAccountDtlId = (long)0;
		Long allocatedAmt=(long)0;
		Long originalAmt = (long)0;
		Long loanId = (long)0;
		String status=null;
		boolean resultFlag=false;
	try{
		 lmsLoanAccountDtlId = (Long) ctx.getValue("/loan_account/ID", Long.class);
		 status=(String) ctx.getValue("/loan_account/STATUS",String.class);
	}
	catch(Exception e){
		
	}
		List<String> logList = new ArrayList<String>();
		int valReplacement=0;
		if(lmsRecievablePayableDtl!=null){
			Iterator<Map<?, ?>> it = lmsRecievablePayableDtl.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()){
					try{
						if (("LOANID").equals(entries.getKey()))
							lmsRecievablePayableDtlLoanId = (Long)entries.getValue();
						if (("ALLOCATEDAMT").equals(entries.getKey()))
							allocatedAmt =(Long) entries.getValue();
						if (("ORIGINALAMT").equals(entries.getKey()))
							originalAmt = (Long) entries.getValue();
					}
					catch(Exception e){
						
					}
					if(allocatedAmt==null){
						allocatedAmt=(long) valReplacement;
					}
					if(originalAmt==null){
						originalAmt=(long) valReplacement;
					}
					if(allocatedAmt>originalAmt){
						if((lmsRecievablePayableDtlLoanId==lmsLoanAccountDtlId)&&("A".equals(status))){
							logList.add("Records where Allocated amount is greater than Original Amount, loan Id and recievable PayableId are equal also Status is 'A' where LoanId is="+lmsRecievablePayableDtlLoanId);
							resultFlag= true;
						}
						else{
							logList.add("Records where Allocated amount is greater than Original Amount, loan Id and recievable PayableId are Not equal also Status is not 'A' where LoanId is="+lmsRecievablePayableDtlLoanId);
							resultFlag=false;
						}
						
					}
					else{
						logList.add("Records where Allocated amount is not greater than Original Amount where Loan Id is="+lmsRecievablePayableDtlLoanId);
						resultFlag= false;
					}
					
				}
		}
		}
		else{
		logList.add("No records found");
		resultFlag= false;
	}
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
