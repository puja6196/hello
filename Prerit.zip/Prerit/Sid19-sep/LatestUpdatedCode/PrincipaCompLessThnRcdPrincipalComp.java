package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class PrincipaCompLessThnRcdPrincipalComp implements RuleExecutor  {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsRecievablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		Long lmsRecievablePayableDtlLoanId = (long)0;
		Long lmsLoanAccountDtlId = (long)0;
		Long principalComponent=(long)0;
		Long principalCompRecieved = (long) 0;
		Long loanId = (long)0;
		String status=null;
		boolean resultFlag=false;
	try{
		 lmsLoanAccountDtlId = (Long) ctx.getValue("/loan_account/ID", Long.class);
		 status=(String) ctx.getValue("/loan_account/STATUS",String.class);
	}
	catch(Exception e){
		
	}
		List<String> logList = new ArrayList<String>();
		int valReplacement=0;
		if(lmsRecievablePayableDtl!=null){
			Iterator<Map<?, ?>> it = lmsRecievablePayableDtl.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()){
					try{
						if (("LOANID").equals(entries.getKey()))
							lmsRecievablePayableDtlLoanId = (Long)entries.getValue();
						if (("PRINCIPAL_COMPONENT").equals(entries.getKey()))
							principalComponent =(Long) entries.getValue();
						if (("PRINCOMP_RECEIVED").equals(entries.getKey()))
							principalCompRecieved = (Long) entries.getValue();
					}
					catch(Exception e){
						
					}	
			if(principalComponent==null){
				principalComponent=(long) valReplacement;
			}
			if(principalCompRecieved==null){
				principalCompRecieved=(long) valReplacement;
			}
			if(principalCompRecieved>principalComponent){
				if((lmsRecievablePayableDtlLoanId==lmsLoanAccountDtlId)&&("A".equals(status))){
					logList.add("Records where LMS_RECEIVABLEPAYABLE_DTL Id is equal to Loan account Id along with Status 'A' and loan Id is:"+lmsRecievablePayableDtlLoanId);
					resultFlag= true;
				}
				else{
					logList.add("Records where LMS_RECEIVABLEPAYABLE_DTL Id is not equal to Loan account Id or along with another Status rather than'A' and loan Id is:"+lmsRecievablePayableDtlLoanId);
					resultFlag=false;
				}
			}
		}
		}
		}else{
		logList.add("No record is found");
		
		resultFlag= false;
	}
		logger.setLog(logList);
		return resultFlag;
	}
	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
