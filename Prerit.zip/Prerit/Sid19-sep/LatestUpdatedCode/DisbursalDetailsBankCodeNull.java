package com.nucleus.tools.datasanitizer.lms;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalDetailsBankCodeNull implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<String>();
	String paymentMode =null;
	Long dealingbank_mst_id = (long)0;
	Long Id = (long)0;
		  List<Map<?,?>> disbursalPaymentDetail = MVEL.eval("loan_account.?disbursal_paymnet_details", context, List.class);
	try{
		 Id = (Long) ctx.getValue("/loan_account/disbursal_paymnet_details/ID", Long.class);
	}
	catch (Exception e){
		
	}
	      boolean resultFlag=false;
	  if(disbursalPaymentDetail!=null){
		  Iterator<Map<?, ?>> it =disbursalPaymentDetail.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()){
					 if (("PAYMENTMODE").equals(entries.getKey()))
						 paymentMode = entries.getValue().toString();
                   if (("DEALINGBANK_MST_ID").equals(entries.getKey()))
                	   dealingbank_mst_id = ((Long) entries.getValue());
                   if(paymentMode!="2670"&&paymentMode!="2669"&&dealingbank_mst_id==null){
     		    	 // if(dealingbank_mst_id==null)
     		    		  logList.add("Records in LMS_DISBURSAL_PAYMENT_DTL table having paymentmode not in cheque and draft and dealing_bank_code is Blank where Id is ="+Id);
     		    		  resultFlag= true;	  
     		      }
                   else{
                	   logList.add("Records in LMS_DISBURSAL_PAYMENT_DTL table having paymentmode in cheque or draft or dealing_bank_code is not Blank, where Id is ="+Id);
                	   resultFlag=false;
                   }
				}  
	  }
	  }logList.add("Disbursal payment details is empty");
	    logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
