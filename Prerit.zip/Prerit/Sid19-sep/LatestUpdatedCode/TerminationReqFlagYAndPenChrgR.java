package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TerminationReqFlagYAndPenChrgR implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> loanTermination = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		String forcedRequestedFlag = null;
		String penaltyChargeNature = null;
		BigDecimal terminationId=new BigDecimal(0);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = false;
		if (loanTermination != null) {
			Iterator<Map<?, ?>> it = loanTermination.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					try {
						if (("FORCED_REQUESTED_FLAG").equals(entries.getKey()))
							forcedRequestedFlag = (String)entries.getValue();
						if (("PENALTY_CHARGE_NATURE").equals(entries.getKey()))
							penaltyChargeNature =(String) entries.getValue();
						if (("ID").equals(entries.getKey()))
							terminationId = (BigDecimal) entries.getValue();
					} catch (NullPointerException e) {

					}
					if (("Y".equalsIgnoreCase(forcedRequestedFlag)&&("R".equals(penaltyChargeNature)))) {
						logList.add(
								"records present in  LMS_TERMINATION_HDR where FORCED_REQUESTED_FLAG is Y and PENALTY_CHARGE_NATURE is R for termination Id:"+terminationId);
						resultFlag = true;
					} else {
						logList.add(
								"Records present in  LMS_TERMINATION_HDR where FORCED_REQUESTED_FLAG is not Y or PENALTY_CHARGE_NATURE is not R for termination Id:"+terminationId);
						resultFlag = false;
					}
				}
			}

		} else { 
			logList.add("No record is found in Termination Hdr");
			resultFlag=false;

		}logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
