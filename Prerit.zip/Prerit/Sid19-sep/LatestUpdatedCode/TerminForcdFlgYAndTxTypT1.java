package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TerminForcdFlgYAndTxTypT1 implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> loanTerminationHdr = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		String forcedRequestedFlag=null;
		String transactionType=null;
		Long id=(long)0;
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = false;
		if (loanTerminationHdr != null) {
			Iterator<Map<?, ?>> it = loanTerminationHdr.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					try {
						if (("FORCED_REQUESTED_FLAG").equals(entries.getKey()))
							forcedRequestedFlag = entries.getValue().toString();
						if (("TRANSACTION_TYPE").equals(entries.getKey()))
							transactionType = entries.getValue().toString();
						if (("ID").equals(entries.getKey()))
							id = (Long) entries.getValue();
					} catch (NullPointerException e) {
						
					}
					if(("Y".equals(forcedRequestedFlag))&&("T1".equals(transactionType))){
						logList.add("Records in LMS Termination with ForcedRequestedFlag is'y' and transaction Type is'T1' where loanId is:"+id);
						resultFlag=true;
					}
					else{ logList.add("Records in LMS Termination with ForcedRequestedFlag is not'y' and transaction Type is not'T1' where loanId is:"+id);
					resultFlag= false;
				}
				}
			}
		}
		else{
			logList.add("No record is found");
			resultFlag=false;
		}
		logger.setLog(logList);
	return resultFlag;			
				}
	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
