package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TerminatedContractsInLoanAcct implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsTerminationHdr = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		Long lmsLoanAccountDtlId=(long)0;
		Long terminationHdrLoanId=(long)0;
		Long loanId=(long)0;
		String lmsTerminationHdrMcStatus=null;
		String lmsLoanAccountDtlStatus=null;
		try {
			 lmsLoanAccountDtlId=(Long)ctx.getValue("/loan_account/ID",Long.class);
			 lmsLoanAccountDtlStatus=(String)ctx.getValue("/loan_account/STATUS",String.class);
		}
		catch(Exception e){
			
		}
		List<String> logList = new ArrayList<String>();
		boolean resultFlag=false;
		if(lmsTerminationHdr!=null){
			Iterator<Map<?, ?>> it = lmsTerminationHdr.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()){
					try{
						if (("LOANID").equals(entries.getKey()))
							terminationHdrLoanId = (Long)entries.getValue();
						if (("MC_STATUS").equals(entries.getKey()))
							lmsTerminationHdrMcStatus =(String) entries.getValue();
					}
					catch(Exception e){
						
					}
					
					if((terminationHdrLoanId==lmsLoanAccountDtlId)&&("A".equals(lmsTerminationHdrMcStatus))&&("A".equals(lmsLoanAccountDtlStatus))){
						logList.add("Number of terminated contracts where status is still active in LMS_LOANACCOUNT_DTL Table along with termination status and loan status equal to 'A' Loan Id is="+terminationHdrLoanId);
						resultFlag= true;
					}
					else{
						logList.add("Number of terminated contracts where status maybe not active in LMS_LOANACCOUNT_DTL Table along with both termination status and loan status not equal to 'A' Loan Id is="+terminationHdrLoanId);
						resultFlag=false;
					}
				}
		}
		}else {
		logList.add("No records found for loan id:"+loanId);
		resultFlag= false;
	}   
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
