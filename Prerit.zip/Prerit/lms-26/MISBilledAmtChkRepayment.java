package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class MISBilledAmtChkRepayment implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger )
	
	    {

		
		     JXPathContext ctx = JXPathContext.newContext(context);
		     Boolean resultFlag=true; 
		     List<String> logList = new ArrayList<String>();
		     
		  
			        BigDecimal billedInterestAmt = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/BILLED_INT_AMT", BigDecimal.class);
			        List<Map<?,?>> loan_repayment = MVEL.eval("loan_account.?loan_repayment", context, List.class);
			  
			         if(loan_repayment!=null)
			           {
				          Iterator<Map<?, ?>> it = loan_repayment.iterator();
				          BigDecimal sumIntComp = new BigDecimal(0);
		                     while (it.hasNext()) 
		                       {
		                          Map<String, String> mapValues = (Map<String, String>) it.next();
				                  BigDecimal vapid = new BigDecimal(0);
			                      BigDecimal interestComponent=new BigDecimal(0);
			                      
			                      String billedFlag=null;
				
				                     for (Map.Entry entries : mapValues.entrySet()) 
				                        {
				                         
		                                  if (("VAPID").equals(entries.getKey()))
		    	                           vapid = ((BigDecimal) entries.getValue());
		      
		                                  if (("INTEREST_COMPONENT").equals(entries.getKey()))
		    	                           interestComponent = ((BigDecimal) entries.getValue());
		       
		                                  if (("BILLED_FLAG").equals(entries.getKey()))
		    	                          billedFlag = (String) entries.getValue().toString();
		                                  
				                        }
		                       
				                          if((billedFlag=="Y")&&(vapid.compareTo(BigDecimal.ZERO)==0))
				                           {
				                        	  sumIntComp=sumIntComp.add(interestComponent);
				 
				                           }
				                          
		                       }
		                     if(billedInterestAmt.compareTo(sumIntComp)!= 0)
                       	   		{
	                           logList.add("Billed interest amount in MIS is not equal to sum of Interest Component.");
	  	                       resultFlag= false; 
	                           }
				                           if(resultFlag)
				                           {
				                        	   logList.add("Billed interest amount in MIS is equal to sum of Interest Component.");
				                           }
				 
				            
				                       
				               }else{
				            	   logList.add("Repayment DEtails are not available.");
				            	   resultFlag=false;
				               }
				 
				 
				 
			            
	
		  
		
		
	 logger.setLog(logList);
     return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
