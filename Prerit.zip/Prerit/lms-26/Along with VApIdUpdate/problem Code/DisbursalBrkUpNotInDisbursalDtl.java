package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalBrkUpNotInDisbursalDtl implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> lmsDistbursalBreakupDetails = MVEL.eval("loan_account.?disbursal_details_breakup", context,
				List.class);
		List<String> logList = new ArrayList<String>();
		JXPathContext ctx = JXPathContext.newContext(context);
		boolean resultFlag = true;
		BigDecimal disbBreakupDtlId = new BigDecimal(0);
		BigDecimal lmsDisbursalId = new BigDecimal(0);
		BigDecimal disbursalAmt = new BigDecimal(0);
		BigDecimal disbursalBrkUpAmt = new BigDecimal(0);
		BigDecimal sumDisbursalBrkUpAmt = new BigDecimal(0);
		BigDecimal vapId = new BigDecimal(0);
		BigDecimal vapId0 = new BigDecimal(0);
		String disbursalStatus = null;
		String disbursalBrkUpStatus = null;
		String loanAcctStatus = null;
		try {
			lmsDisbursalId = (BigDecimal) ctx.getValue("/loan_account/disbursal_details/ID", BigDecimal.class);
			disbursalAmt = (BigDecimal) ctx.getValue("/loan_account/disbursal_details/Disbursal_Amt", BigDecimal.class);
			disbursalStatus = (String) ctx.getValue("/loan_account/disbursal_details/Disbursal_Status", String.class);
			vapId = (BigDecimal) ctx.getValue("/loan_account/disbursal_details/VAPID", BigDecimal.class);
			loanAcctStatus = (String) ctx.getValue("/loan_account/Status", String.class);
		} catch (Exception e) {
			logList.add("Exception occured while Retrieving data from Disbursal Details or Loan Account");
		}
		if (disbursalAmt == null)
			disbursalAmt = BigDecimal.ZERO;
		if (lmsDistbursalBreakupDetails != null) {
			Iterator<Map<?, ?>> it = lmsDistbursalBreakupDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					try {
						if (("ID").equals(entries.getKey()))
							disbBreakupDtlId = (BigDecimal) entries.getValue();
						if (("Disbursal_Status").equals(entries.getKey()))
							disbursalBrkUpStatus = (String) entries.getValue();
						if (("Disbursal_Amt").equals(entries.getKey()))
							disbursalBrkUpAmt = (BigDecimal) entries.getValue();
					} catch (Exception e) {
						logList.add("Exception occured while retrieving data from Disbursal BreakUp Details");
					}

					if ((disbBreakupDtlId.compareTo(lmsDisbursalId) == 0) && ("A".equals(disbursalBrkUpStatus))) {
						sumDisbursalBrkUpAmt = sumDisbursalBrkUpAmt.add(disbursalBrkUpAmt);
					}
					if (sumDisbursalBrkUpAmt == null)
						sumDisbursalBrkUpAmt = BigDecimal.ZERO;
				}
			}
			if (vapId.compareTo(vapId0) == 0) {
				if (disbursalAmt.compareTo(sumDisbursalBrkUpAmt) == 0) {
					// Do nothing
				} else if (("A".equals(disbursalStatus)) && ("A".equals(loanAcctStatus))) {
					logList.add("Lms Disbursal dtl does not exist in Disbursal BreakUp Details");
					resultFlag = false;
				}
			}
		} else {
			logList.add("No data exist in Disbursal BreakUp Details");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add("Lms Disbursal dtl does exist in Disbursal BreakUp Details");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
