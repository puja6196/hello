package com.nucleus.tools.datasanitizer.lms.vapIdmod;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbDtlsMandFieldsChk implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		List<Map<?, ?>> disbursalDetails = MVEL.eval("loan_account.?disbursal_payment_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if (disbursalDetails != null) {

			Iterator<Map<?, ?>> it = disbursalDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				BigDecimal id = new BigDecimal(0);
				BigDecimal disbursal_BreakupId = new BigDecimal(0);
				String paymentMode = null;
				BigDecimal payment_Amount = new BigDecimal(0);
				Date instrument_Date = null;
				String ignore_For_Download = null;
				String disbursal_Payment_Status = null;
				BigDecimal receipt_Payment_Id = new BigDecimal(0);
				BigDecimal dealingbank_Mst_Id = new BigDecimal(0);
				BigDecimal vapId = new BigDecimal(0);
				BigDecimal vapId0 = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("ID").equals(entries.getKey()))
						id = (BigDecimal) entries.getValue();
					if (("DISBURSAL_BREAKUPID").equals(entries.getKey()))
						disbursal_BreakupId = (BigDecimal) entries.getValue();
					if (("PAYMENTMODE").equals(entries.getKey()))
						paymentMode = ((String) entries.getValue().toString());
					if (("PAYMENT_AMOUNT").equals(entries.getKey()))
						payment_Amount = (BigDecimal) (entries.getValue());
					if (("INSTRUMENT_DATE").equals(entries.getKey()))
						instrument_Date = (Date) entries.getValue();
					if (("IGNORE_FOR_DOWNLOAD").equals(entries.getKey()))
						ignore_For_Download = (String) entries.getValue().toString();
					if (("DISBURSAL_PAYMENT_SATTUS").equals(entries.getKey()))
						disbursal_Payment_Status = (String) entries.getValue().toString();
					if (("RECEIPT_PAYMENT_ID").equals(entries.getKey()))
						receipt_Payment_Id = (BigDecimal) entries.getValue();
					if (("DEALINGBANK_MST_ID").equals(entries.getKey()))
						dealingbank_Mst_Id = (BigDecimal) entries.getValue();
					if (("VAPID").equals(entries.getKey()))
						vapId = (BigDecimal) entries.getValue();
					if(vapId==null)
						vapId=BigDecimal.ZERO;
				}

				if (vapId.compareTo(vapId0) == 0) {
					if (disbursal_BreakupId == null) {
						logList.add("Disbursal Breakup Id is null for disbursal payment id: " + id);
						resultFlag = false;
					}
					if (paymentMode == null) {
						logList.add("Payment Mode is null for disbursal payment id: " + id);
						resultFlag = false;
					}
					if (payment_Amount == null) {
						logList.add("Payment Amount is null for disbursal payment id: " + id);
						resultFlag = false;
					}
					if (instrument_Date == null) {
						logList.add("Instrument Date is null for disbursal payment id: " + id);
						resultFlag = false;
					}
					if (ignore_For_Download == null) {
						logList.add("Ignore for Download is null for disbursal payment id: " + id);
						resultFlag = false;
					}
					if (disbursal_Payment_Status == null) {
						logList.add("Disbursal Payment Status is null for disbursal payment id: " + id);
						resultFlag = false;
					}
					if (receipt_Payment_Id == null) {
						logList.add("Receipt Payment Id is null for disbursal payment id: " + id);
						resultFlag = false;
					}
					if (dealingbank_Mst_Id == null) {
						logList.add("Dealing bank mst id is null for disbursal payment id: " + id);
						resultFlag = false;
					}

				}

			}

			if (resultFlag) {

				logList.add("Mandatory Fields are not null in Disbursal payment details.");

			}
		} else {
			logList.add("Disbursal Payment Details are not available.");
			// resultFlag=false;

		}

		logger.setLog(logList);
		return resultFlag;

	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
