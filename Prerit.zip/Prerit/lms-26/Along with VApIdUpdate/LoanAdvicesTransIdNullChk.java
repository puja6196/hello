package com.nucleus.tools.datasanitizer.lms.vapIdmod;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAdvicesTransIdNullChk implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		List<Map<?, ?>> adviceDetails = MVEL.eval("loan_account.?advice_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		BigDecimal vapId = new BigDecimal(0);
		boolean returnFlag = true;
		if (adviceDetails != null) {
			Iterator<Map<?, ?>> it = adviceDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				String transaction_type = null;
				BigDecimal transaction_id = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("TRANSACTION_TYPE").equals(entries.getKey()))
						transaction_type = entries.getValue().toString();
					if (("TRANSACTIONID").equals(entries.getKey()))
						transaction_id = ((BigDecimal) entries.getValue());
					if (("VAPID").equals(entries.getKey()))
						vapId = (BigDecimal) entries.getValue();
					if(vapId==null)
						vapId=BigDecimal.ZERO;
				}
				if (vapId.compareTo(new BigDecimal(0)) == 0) {
					if ("B".equalsIgnoreCase(transaction_type) || "G".equalsIgnoreCase(transaction_type)
							|| "V".equalsIgnoreCase(transaction_type)) {

						if (transaction_id == null) {
							logList.add("Transaction Id is null for transaction type : " + transaction_type
									+ " and Transaction Id : " + transaction_id);
							returnFlag = false;
						}
					}
				}

			}
			if (returnFlag) {
				logList.add("Transaction Id is not null for transaction types B,G and V.");

			}
		} else {
			logList.add("Advice Details are not available.");

			returnFlag = false;
		}

		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
