package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanMISPersistanceStatusWrongEntity implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<String>();
		Boolean resultFlag = true;

		if (ctx != null) {
			BigDecimal entityVersionId = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/ENTITY_VERSION_ID",
					BigDecimal.class);
			BigDecimal persistenceStatus = (BigDecimal) ctx
					.getValue("/loan_account/loan_mis_details/PERSISTENCE_STATUS", BigDecimal.class);
			if (entityVersionId == null) {
				entityVersionId = BigDecimal.ZERO;

			}
			if (persistenceStatus == null) {

				persistenceStatus = BigDecimal.ONE;

			}

			if (entityVersionId.compareTo(BigDecimal.ZERO) == 0 || persistenceStatus.compareTo(BigDecimal.ZERO) != 0)

			{
				logList.add("MIS Details having Entity version Id as Zero or Persistence Status as Non Zero");
				resultFlag = false;

			}

		} else {
			resultFlag = false;
		}
		if(resultFlag)
		logList.add("MIS Details having Entity version Id as non Zero and Persistence Status as Zero");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
