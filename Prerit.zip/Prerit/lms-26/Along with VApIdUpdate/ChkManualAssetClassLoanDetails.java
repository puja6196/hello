package com.nucleus.tools.datasanitizer.lms.vapIdmod;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManualAssetClassLoanDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal vapId0 = new BigDecimal(0);
		String autoManualClassifyFlag = (String) ctx.getValue("/loan_account/AUTO_MANUAL_CLASSIFY_FLAG", String.class);
		BigDecimal assetClassMstId = (BigDecimal) ctx.getValue("/loan_account/ASSET_CLASS_MST_ID", BigDecimal.class);
		BigDecimal vapId = (BigDecimal) ctx.getValue("/loan_account/VAPID", BigDecimal.class);
		BigDecimal lastManualAssetclassMstId = (BigDecimal) ctx.getValue("/loan_account/LAST_MANUAL_ASSET_CLASS_MST_ID",
				BigDecimal.class);
		BigDecimal assetClassMstIdval = BigDecimal.ONE;
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if(vapId==null)
			vapId=BigDecimal.ZERO;
		if (vapId.compareTo(vapId0) == 0) {
			if ("M".equalsIgnoreCase(autoManualClassifyFlag)
					&& ((assetClassMstIdval.compareTo(assetClassMstId) == 1)
							|| (assetClassMstIdval.compareTo(assetClassMstId) == 1))
					&& lastManualAssetclassMstId == null) {
				logList.add(
						"Auto manual classify flag is 'M' and asset class mst id is not equal to 1 and last manual asset mst id is null.");
				returnFlag = false;
			}
		}
		if (returnFlag) {
			logList.add("Manual asset class id is not null.");
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
