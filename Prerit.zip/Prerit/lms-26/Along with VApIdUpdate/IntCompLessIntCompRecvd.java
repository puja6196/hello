package com.nucleus.tools.datasanitizer.lms.vapIdmod;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class IntCompLessIntCompRecvd implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> lmsRecievablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal intComp = new BigDecimal(0);
		BigDecimal intCompRecvd = new BigDecimal(0);
		BigDecimal adviceId = new BigDecimal(0);
		BigDecimal vapId = new BigDecimal(0);
		List<String> logList = new ArrayList<String>();
		String status = null;
		boolean resultFlag = true;
		try {
			status = (String) ctx.getValue("/loan_account/STATUS", String.class);
		} catch (Exception e) {
			logList.add("Exception occured while fetching loan details.");
		}
		if (lmsRecievablePayableDtl != null) {
			Iterator<Map<?, ?>> it = lmsRecievablePayableDtl.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					try {
						if (("INTEREST_COMPONENT").equals(entries.getKey()))
							intComp = (BigDecimal) entries.getValue();
						if (("INTCOMP_RECEIVED").equals(entries.getKey()))
							intCompRecvd = (BigDecimal) entries.getValue();
						if (("ID").equals(entries.getKey()))
							adviceId = (BigDecimal) entries.getValue();
						if (("VAPID").equals(entries.getKey()))
							vapId = (BigDecimal) entries.getValue();
						if(vapId==null)
							vapId=BigDecimal.ZERO;
						if (intComp == null)
							intComp = BigDecimal.ZERO;
						if (intCompRecvd == null)
							intCompRecvd = BigDecimal.ZERO;
					} catch (Exception e) {
						logList.add("Exception occured while fetching Recievable Payable fields data.");
					}
				}
				if (vapId.compareTo(new BigDecimal(0)) == 0) {
					if (status.equals("A")) {
						if (intComp.compareTo(intCompRecvd) == -1) {
							logList.add("Interest component is less than received Interest component for Advice Id : "
									+ adviceId);
							resultFlag = false;
						}
					}
				}
			}
		} else {
			logList.add("No data is found in Advice Details.");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add("Interest component is not less than received Interest component.");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
