package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TerForcedReqFlagNTranTypT2 implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{

        boolean returnFlag=true;

        List<String> logList = new ArrayList<String>();

        List<Map<?,?>> terminationDetails = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);

       

        if(terminationDetails!=null)
                  {
					
	              Iterator<Map<?, ?>> it = terminationDetails.iterator();
	              while (it.hasNext())
						
	                    {
		                  Map<String,String> mapValues = (Map<String, String>) it.next();
		
		                    String forcedReqFlag=null;
		                    String transactionType=null;
		                    BigDecimal terminationId = new BigDecimal(0);
		                      for (Map.Entry entries : mapValues.entrySet())
		                            {
			                          if(("FORCED_REQUESTED_FLAG").equals(entries.getKey()))
			                                 {
			                        	  forcedReqFlag=(String) entries.getValue();
				
			                                 }
			                          if(("TRANSACTION_TYPE").equals(entries.getKey()))
		                                     {
			                        	  transactionType=(String) entries.getValue();
			
		                                     } 
			                          if(("ID").equals(entries.getKey()))
		                                 {
		                        	  terminationId=(BigDecimal) entries.getValue();
			
		                                 }
		                            }
				                       if((forcedReqFlag.equals("N")||forcedReqFlag== null ) &&(transactionType.equals("T2")))
				                             {
				                    	   
				                    	   returnFlag=false;
				                    	   logList.add("FORCED_REQUESTED_FLAG is N or NULL for TRANSACTION_TYPE T2 for termination hdr id : "+terminationId);
				                       		                       
				                             }
				                      
				                       
				        }
	              if(returnFlag)
                  {
               	   
               	   logList.add("FORCED_REQUESTED_FLAG is not N or NULL for TRANSACTION_TYPE T2");
               	   
                  }
		                    
	               }
       else
                {
        	              logList.add("Termination Details are not available.");
//        	              returnFlag=false;
        	              
        	        	
                }
        logger.setLog(logList);
        return returnFlag;
	
	}

	@Override
	public boolean shouldExecute(RootObject arg0) 
	{
		
		return true;
	}

}
