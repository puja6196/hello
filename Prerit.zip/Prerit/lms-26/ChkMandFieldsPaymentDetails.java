package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandFieldsPaymentDetails implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		
		List<Map<?,?>> paymentdetails = MVEL.eval("loan_account.?payment_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if(paymentdetails!=null){
			Iterator<Map<?, ?>> it = paymentdetails.iterator();
			while(it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>)it.next();
				BigDecimal id=new BigDecimal(0);
				String loan_account_number=null;
				BigDecimal bpTypeId=new BigDecimal(0);
				String customer_no=null;
				BigDecimal curreny_mst_id=new BigDecimal(0);
				BigDecimal loan_Branchid=new BigDecimal(0);
//				BigDecimal loanId=new BigDecimal(0);
				String status=null;
				String mc_status=null;
				BigDecimal productid=new BigDecimal(0);
				BigDecimal transaction_amount=new BigDecimal(0);
				BigDecimal paymentmode=new BigDecimal(0);
				BigDecimal receiptpayment_type=new BigDecimal(0);
				BigDecimal txn_branchid=new BigDecimal(0);
				BigDecimal txn_currency_mst_id=new BigDecimal(0);
				Date transaction_date=null;
				Date txn_value_date=null;
				BigDecimal receiptAgainst=new BigDecimal(0);
				BigDecimal receiptAgainstval = new BigDecimal(51129);
				for(Map.Entry entries : mapValues.entrySet()){
					if("ID".equals(entries.getKey()))
						id= (BigDecimal) entries.getValue();
					if("LOAN_ACCOUNT_NO".equals(entries.getKey()))
						loan_account_number=entries.getValue().toString();
					if("BPTYPE_ID".equals(entries.getKey()))
						bpTypeId=(BigDecimal) entries.getValue();
					if("CUSTOMER_NO".equals(entries.getKey()))
						customer_no=entries.getValue().toString();
					if("CURRENCY_MST_ID".equals(entries.getKey()))
						curreny_mst_id=(BigDecimal)entries.getValue();
					if("LOAN_BRANCHID".equals(entries.getKey()))
						loan_Branchid=(BigDecimal)entries.getValue();
//					if("LOANID".equals(entries.getKey()))
//						loanId=(BigDecimal)entries.getValue();
					if("STATUS".equals(entries.getKey()))
						status=entries.getValue().toString();
					if("MC_STATUS".equals(entries.getKey()))
						mc_status=entries.getValue().toString();
					if("PRODUCTID".equals(entries.getKey()))
						productid=(BigDecimal)entries.getValue();
					if("TRANSACTION_AMOUNT".equals(entries.getKey()))
						transaction_amount=(BigDecimal) entries.getValue();
					if("PAYMENTMODE".equals(entries.getKey()))
						paymentmode= (BigDecimal)entries.getValue();
					if("RECEIPTPAYMENT_TYPE".equals(entries.getKey()))
						receiptpayment_type=(BigDecimal)entries.getValue();
					if("TXN_BRANCHID".equals(entries.getKey()))
						txn_branchid=(BigDecimal)entries.getValue();
					if("TXN_CURRENCY_MST_ID".equals(entries.getKey()))
						txn_currency_mst_id=(BigDecimal)entries.getValue();
					if("TRANSACTION_DATE".equals(entries.getKey()))
						transaction_date=(Date) entries.getValue();
					if("TXN_VALUE_DATE".equals(entries.getKey()))
						txn_value_date=(Date) entries.getValue();
					if("RECEIPT_AGAINST".equals(entries.getKey()))
						receiptAgainst=(BigDecimal) entries.getValue();
				}
				if(((receiptAgainstval.compareTo(receiptAgainst)==-1) || (receiptAgainstval.compareTo(receiptAgainst)==1)) && (status!="X" || status!="B")){
					if(id==null){
						logList.add("Id is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(loan_account_number.isEmpty()){
						logList.add("Loan Account Number is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(customer_no.isEmpty()){
						logList.add("Customer Number is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(curreny_mst_id==null){
						logList.add("Currency mst id is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(loan_Branchid==null){
						logList.add("Loan Branch id is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(mc_status.isEmpty()){
						logList.add("MC status is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(productid==null){
						logList.add("Product id is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(transaction_amount==null){
						logList.add("Transaction amount is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(paymentmode==null){
						logList.add("Payment mode is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(receiptpayment_type==null){
						logList.add("Receipt pay type is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(txn_branchid==null){
						logList.add("Transaction Branch Id is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(txn_currency_mst_id==null){
						logList.add("Transaction Currency Mst Id is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(transaction_date==null){
						logList.add("Transaction Date is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(txn_value_date==null){
						logList.add("Transaction Value Date is null for Payment Id :"+id);
						resultFlag=false;
					}
					if(bpTypeId==null){
						logList.add("BP Type Id is null for Payment Id :"+id);
						resultFlag=false;
					}
				}
				if(resultFlag){
					logList.add("Id,Loan Account Number,Customer Number,Currency mst id,Loan Branch id,MC status,Product id,Transaction amount,Payment mode,Receipt pay type,Transaction Branch Id,Transaction Currency Mst Id,Transaction Date,Transaction Value Date are not null.");
				}
				
			}
		}else{
			logList.add("Payment details are not avilable.");
			resultFlag=false;
		}
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		return true;
	}

}
