package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandFieldLoanAdviceDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		
		
		List<Map<?,?>> advicedetails = MVEL.eval("loan_account.?advice_details", context, List.class);
		boolean returnFlag=true;
		List<String> logList = new ArrayList<String>();
		if(advicedetails!=null){
			
			Iterator<Map<?,?>> itr= advicedetails.iterator();
			while(itr.hasNext()){
				Map<String,String> mValues= (Map<String, String>) itr.next();
				BigDecimal bptype_id=new BigDecimal(0);
				BigDecimal chargecode=new BigDecimal(0);
				BigDecimal chargecode_mst_id=new BigDecimal(0);
				Date duedate=null;
				BigDecimal charge_mst_id=new BigDecimal(0);
				BigDecimal currency_mst_id=new BigDecimal(0);
				String customer_no=null;
				BigDecimal loanId= new BigDecimal(0);
				BigDecimal originalamt= new BigDecimal(0);
				BigDecimal recieve_Payable_amount= new BigDecimal(0);
				String recieve_payable_flag=null;
				Date recieve_payable_date=null;
				BigDecimal id = new BigDecimal(0);
				for(Map.Entry entries : mValues.entrySet()){
					if("BPTYPE_ID".equals(entries.getKey()))
						bptype_id= (BigDecimal) entries.getValue();
					if("CHARGECODE".equals(entries.getKey()))
						chargecode= (BigDecimal) entries.getValue();
					if("CHARGECODE_MST_ID".equals(entries.getKey()))
						chargecode_mst_id= (BigDecimal)entries.getValue();
					if("DUEDATE".equals(entries.getKey()))
						duedate= (Date) entries.getValue();
					if("CHARGE_MST_ID".equals(entries.getKey()))
						charge_mst_id=  (BigDecimal)entries.getValue();
					if("CURRENCY_MST_ID".equals(entries.getKey()))
						currency_mst_id=  (BigDecimal)entries.getValue();
					if("CUSTOMER_NO".equals(entries.getKey()))
						customer_no=  entries.getValue().toString();
					if("LOANID".equals(entries.getKey()))
						loanId= (BigDecimal) entries.getValue();
					if("ORIGINALAMT".equals(entries.getKey()))
						originalamt= (BigDecimal) entries.getValue();
					if("RECEIVABLE_PAYABLE_AMT".equals(entries.getKey()))
						recieve_Payable_amount= (BigDecimal) entries.getValue();
					if("RECEIVABLE_PAYABLE_FLAG".equals(entries.getKey()))
						recieve_payable_flag=  entries.getValue().toString();
					if("RECEIVABLE_PAYABLE_DATE".equals(entries.getKey()))
						recieve_payable_date= (Date) entries.getValue();
					if(("ID").equals(entries.getKey())){
						id = (BigDecimal) entries.getValue();
					}
				}
				
					if(bptype_id==null){
						logList.add("BP type Id is null in advice details for  id: "+id);
						returnFlag=false;
					
					}
					if(chargecode==null){
						logList.add("Charge code is null in advice details for id: "+id);
						returnFlag=false;
						
					}
					if(chargecode_mst_id==null){
						logList.add("Charge code mst id is null in advice details for id: "+id);
						returnFlag=false;
						
						
					}
					if(duedate==null){
						logList.add("Due date is null in advice details for id: "+id);
						returnFlag=false;
						
					}
					if(charge_mst_id==null){
						logList.add("Charge mst Id is null in advice details for id: "+id);
						returnFlag=false;
						
					}
					if(currency_mst_id==null){
						logList.add("Currency mst id is null in advice details for id: "+id);
						returnFlag=false;
			
					}
					if(customer_no==null){
						logList.add("Customer number is null in advice details for id: "+id);
						returnFlag=false;
				
					}
					if(loanId==null){
						logList.add("LoanId is null in advice details");
						returnFlag=false;
				
					}
					if(originalamt==null){
						logList.add("Original Amount is null in advice details for id: "+id);
						returnFlag=false;
					
					}
					if(recieve_Payable_amount==null){
						logList.add("Receivable Payble amount is null in advice details for id: "+id);
						returnFlag=false;
			
					}
					if(recieve_payable_flag==null){
						logList.add("Receivable Payble flag is null in advice details for id: "+id);
						returnFlag=false;
				
					}
					if(recieve_payable_date==null){
						logList.add("Receivable Payble date is null in advice details for id: "+id);
						returnFlag=false;
				
					}
				
				}
			if(returnFlag){
				logList.add("BP type Id,Charge code,Charge code mst id,Due date,Charge mst Id,Currency mst id,Customer number,Original Amount,Receivable Payble amount,Receivable Payble date are not null.");
				
			}
			}else
			{
				logList.add("Advice details are not avilable.");
				returnFlag=false;
		
			}
			
			logger.setLog(logList);
			return returnFlag;
			}
			
		

	

	@Override
	public boolean shouldExecute(RootObject arg0) {
		return true;
	}

}
