package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFieldsLoanRepayment implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> repaymentDetails = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if (repaymentDetails != null) {
			Iterator<Map<?, ?>> it = repaymentDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				BigDecimal installment_amount = new BigDecimal(0);
				BigDecimal principal_component = new BigDecimal(0);
				BigDecimal interest_component = new BigDecimal(0);
				String advance_repay_flag = null;
				BigDecimal closing_principal = new BigDecimal(0);
				Date due_date = null;
				String emi_pemi_flag = null;
				BigDecimal installment_number = new BigDecimal(0);
				BigDecimal balance_principal = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("INSTALMENT_AMOUNT").equals(entries.getKey()))
						installment_amount = (BigDecimal) entries.getValue();
					if (("PRINCIPAL_COMPONENT").equals(entries.getKey()))
						principal_component = (BigDecimal) entries.getValue();
					if (("INTEREST_COMPONENT").equals(entries.getKey()))
						interest_component = (BigDecimal) entries.getValue();
					if (("ADVANCE_PREPAY_FLAG").equals(entries.getKey()))
						advance_repay_flag = entries.getValue().toString();
					if (("CLOSING_PRINCIPAL").equals(entries.getKey()))
						closing_principal = (BigDecimal) entries.getValue();
					if (("DUEDATE").equals(entries.getKey()))
						due_date = (Date) entries.getValue();
					if (("EMI_PEMI_FLAG").equals(entries.getKey()))
						emi_pemi_flag = entries.getValue().toString();
					if (("INSTALMENT_NUMBER").equals(entries.getKey()))
						installment_number = ((BigDecimal) entries.getValue());
					if (("BALANCE_PRINCIPAL").equals(entries.getKey()))
						balance_principal = (BigDecimal) entries.getValue();
				}

				if (installment_amount == null ){				
					logList.add("INSTALLMENT_AMOUNT in Loan Repayment is null for Instal# : "+installment_number);
					returnFlag = false;
				}
				if (principal_component == null ){
					logList.add("PRINCIPAL_COMPONENT in Loan Repayment is null for Instal# : "+installment_number);
					returnFlag = false;
				}
				if (interest_component == null ){
					logList.add("INTREST_COMPONENT in Loan Repayment is null for Instal# : "+installment_number);
					returnFlag = false;

				}
				if ((advance_repay_flag == null)) {
					logList.add("ADVANCE_REPAY_FLAG in Loan Repayment is null for Instal# : "+installment_number);
					returnFlag = false;

				}
				if (closing_principal == null ){
					logList.add("CLOSING_PRINCIPAL in Loan Repayment is null for Instal# : "+installment_number);
					returnFlag = false;

				}
				if ((due_date == null)) {
					logList.add("DUEDATE in Loan Repayment is null for Instal# : "+installment_number);
					returnFlag = false;

				}
				if ((emi_pemi_flag == null)) {
					logList.add("EMI_PEMI_FLAG in Loan Repayment is null for Instal# : "+installment_number);
					returnFlag = false;

				}
				if (installment_number == null ) {
					logList.add("INSTALLMENT_NUMBER in Loan Repayment is null for Instal# : "+installment_number);
					returnFlag = false;

				}
				if (balance_principal == null ) {
					logList.add("BALANCE_PRINCIPAL in Loan Repayment is null for Instal# : "+installment_number);
					returnFlag = false;

				}

			}
			if (returnFlag) {
				logList.add(
						"INSTALLMENT_AMOUNT, PRINCIPAL_COMPONENT, INTREST_COMPONENT, ADVANCE_REPAY_FLAG, CLOSING_PRINCIPAL, DUEDATE, EMI_PEMI_FLAG, INSTALLMENT_NUMBER, BALANCE_PRINCIPAL data is not null.");

			}
		} else {
			returnFlag = false;
			logList.add("Repayment Schedule is not available.");

		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {

		return true;
	}

}
