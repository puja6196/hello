package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.JXPathContext;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFieldsLoanDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);

		BigDecimal repay_policy_id = (BigDecimal) ctx.getValue("/loan_account/REPAY_POLICY_ID", BigDecimal.class);
		BigDecimal schemeid = (BigDecimal) ctx.getValue("/loan_account/SCHEMEID", BigDecimal.class);
		BigDecimal productid = (BigDecimal) ctx.getValue("/loan_account/PRODUCTID", BigDecimal.class);
		BigDecimal currency_mst_id = (BigDecimal) ctx.getValue("/loan_account/CURRENCY_MST_ID", BigDecimal.class);
		BigDecimal branchid = (BigDecimal) ctx.getValue("/loan_account/BRANCHID", BigDecimal.class);
		BigDecimal pemi_tenure_inclusive_flag = (BigDecimal) ctx.getValue("/loan_account/PEMI_TENURE_INCLUSIVE_FLAG", BigDecimal.class);

		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;

		if (repay_policy_id==null) {
			logList.add("Repayment Policy Id is null.");
			returnFlag = false;
		}
		if (schemeid ==null) {
			logList.add("Scheme Id is null.");
			returnFlag = false;
		}
		if (productid ==null) {
			logList.add("Product Id is null.");
			returnFlag = false;
		}
		if (currency_mst_id==null) {
			logList.add("Currency Mst Id is null.");
			returnFlag = false;
		}
		if (branchid ==null) {
			logList.add("Branch Id is null.");
			returnFlag = false;
		}
		if (pemi_tenure_inclusive_flag ==null) {
			logList.add("Pemi Tenure Inclusive Flag of is null.");
			returnFlag = false;
		}

		if (returnFlag) {
			logList.add(
					"Repayment Policy Id,Scheme Id,Product Id,Currency Mst Id,Branch Id,Pemi Tenure Inclusive Flag are not null.");
		}

		logger.setLog(logList);
		return returnFlag;

	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
