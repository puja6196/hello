package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RecdIntAmtNotEqualsSumIntRecdAmt implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> recievablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal recdIntAmt=new BigDecimal(0);
		boolean resultFlag=false;
		recdIntAmt = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/RECD_INT_AMT", BigDecimal.class);
		BigDecimal chargeCode=new BigDecimal(0);
		BigDecimal chargeCode9=new BigDecimal(9);
		String status=null;
		BigDecimal vapId=new BigDecimal(0);
		BigDecimal sumIntComp=new BigDecimal(0);
		BigDecimal intCompRecieved=new BigDecimal(0);
		if(recievablePayableDtl!=null){
			Iterator<Map<?, ?>> it = recievablePayableDtl.iterator();
            while (it.hasNext()) {
            	
                    Map<String, String> mapValues = (Map<String, String>) it.next();
                    for (Map.Entry entries : mapValues.entrySet()){
                    	
						if (("CHARGECODE").equals(entries.getKey()))
							chargeCode =(BigDecimal) entries.getValue();
						if (("VAPID").equals(entries.getKey()))
							vapId = (BigDecimal) entries.getValue();
						if (("STATUS").equals(entries.getKey()))
							status = (String) entries.getValue();
						if (("INTCOMP_RECEIVED").equals(entries.getKey()))
							intCompRecieved = (BigDecimal)entries.getValue();
						if(intCompRecieved==null)
							intCompRecieved=BigDecimal.ZERO;
						
						
                   
                    }
                    if(("A".equals(status))&&(chargeCode.equals(chargeCode9))&&(vapId.equals(BigDecimal.ZERO))){
						sumIntComp=sumIntComp.add(intCompRecieved);
					}
            
		}
            if((recdIntAmt.compareTo(sumIntComp)==0)){
            	//do nothing
            }else{
            	
				logList.add("Recd_Int_Amount in MIS is not equal to sum of int Comp Recieved");
				resultFlag=false;
			}
            if(resultFlag)
            	logList.add("Recd_Int_Amount in MIS is equal to sum of int Comp Recieved");
	}
		else{
			logList.add("No records found for advice details.");
			resultFlag=false;
		}
		logger.setLog(logList);
		return resultFlag;
	}
	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
