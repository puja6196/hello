package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandFieldsLoanReschedule implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		List<Map<?, ?>> rescheduledDetails = MVEL.eval("loan_account.?loan_reschedule_details", context, List.class);
		if (rescheduledDetails != null) {
			Iterator<Map<?, ?>> it = rescheduledDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				BigDecimal balance_installments = new BigDecimal(0);
				BigDecimal anchor_mst_id = new BigDecimal(0);
				BigDecimal change_type = new BigDecimal(0);
				BigDecimal rescheduleId = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("BALANCE_INSTALLMENTS").equals(entries.getKey()))
						balance_installments = ((BigDecimal) entries.getValue());
					if (("ANCHOR_MST_ID").equals(entries.getKey()))
						anchor_mst_id = ((BigDecimal) entries.getValue());
					if (("CHANGE_TYPE").equals(entries.getKey()))
						change_type = ((BigDecimal) entries.getValue());
					if (("ID").equals(entries.getKey()))
						rescheduleId = ((BigDecimal) entries.getValue());

				}
				if (balance_installments == null ) {
					logList.add("Balance Installments in reschedule details is null for Reschedule Id : "+rescheduleId);
					returnFlag = false;
				}
				if (anchor_mst_id == null ) {
					logList.add("Anchor Mst Id in reschedule details is null for Reschedule Id : "+rescheduleId);
					returnFlag = false;
				}
				if (change_type == null ) {
					logList.add("Change Type in reschedule details is null for Reschedule Id : "+rescheduleId);
					returnFlag = false;
				}

			}
			if (returnFlag) {
				logList.add(
						"Balance Installments, Anchor Mst Id, Change Type in reschedule details are not null.");

			}
		} else {
			returnFlag = false;
			logList.add("Loan Reschedule Details are not available.");

		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
