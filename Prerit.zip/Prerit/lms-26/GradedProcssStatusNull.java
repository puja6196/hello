package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class GradedProcssStatusNull implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		boolean returnFlag = true;
		BigDecimal gradedDetailsId = new BigDecimal(0);
		List<String> logList = new ArrayList<String>();

		List<Map<?, ?>> loanGradedData = MVEL.eval("loan_account.?graded_slab_details", context, List.class);
		if (loanGradedData != null) {

			Iterator<Map<?, ?>> it = loanGradedData.iterator();
			while (it.hasNext())

			{
				Map<String, String> mapValues = (Map<String, String>) it.next();

				String processStatus = null;

				for (Map.Entry entries : mapValues.entrySet()) {
					if (("PROCESS_STATUS").equals(entries.getKey())) {
						processStatus = (String) entries.getValue();
					}
					if (("ID").equals(entries.getKey())) {
						gradedDetailsId = (BigDecimal) entries.getValue();

					}

				}
				if (processStatus == null) {
					logList.add("Process Status is null for Graded details Id : " + gradedDetailsId);
					returnFlag = false;

				}

			}

		} else {
			returnFlag = false;
			logList.add("Graded data is not available.");
		}

		if (returnFlag)
			logList.add("Process Status is not null for graded data details.");

		logger.setLog(logList);
		return returnFlag;

	}

	@Override
	public boolean shouldExecute(RootObject context) {
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal gradedYes = new BigDecimal(51120);
		BigDecimal gradedFlag = (BigDecimal)ctx.getValue("/loan_account/LOAN_GRADED_INSTALLMENT_FLAG", BigDecimal.class);
		return (gradedYes.compareTo(gradedFlag)==0);
	}

}
