package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.JXPathContext;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanSecuritizedDealFlgChk implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		String securitizedFlag = null;
		BigDecimal securitizedDealId= new BigDecimal(0);
		List<String> logList = new ArrayList<String>();
	    boolean resultFlag=true; 
	
			securitizedFlag = (String) ctx.getValue("/loan_account/SECURITIZED_FLAG", String.class);
			securitizedDealId = (BigDecimal) ctx.getValue("/loan_account/SECURITIZED_DEALID", BigDecimal.class);
			 
		
		if((securitizedDealId==null)&&("Y".compareTo(securitizedFlag)==0)){
			logList.add("Securitized Deal Id is null and Securitized Flag is 'Y'.");
			resultFlag=false;
		}
		
		if(resultFlag){
			logList.add("Securitized Deal Id is not null and Securitized Flag is 'Y'.");
		
		}
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject logger) {
		// TODO Auto-generated method stub
		return true;
	}

}
