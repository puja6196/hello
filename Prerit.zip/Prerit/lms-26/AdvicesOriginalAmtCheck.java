package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class AdvicesOriginalAmtCheck implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		JXPathContext ctx = JXPathContext.newContext(context);
		Boolean resultFlag = true;
		List<String> logList = new ArrayList<String>();

		char status = (char) ctx.getValue("/loan_account/STATUS", char.class);
		List<Map<?, ?>> receivablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);

		if (receivablePayableDtl != null) {

			Iterator<Map<?, ?>> it = receivablePayableDtl.iterator();
			while (it.hasNext()) {

				Map<String, String> mapValues = (Map<String, String>) it.next();
				BigDecimal allocatedAmt = new BigDecimal(0);
				BigDecimal amtInProcess = new BigDecimal(0);
				BigDecimal originalAmt = new BigDecimal(0);
				BigDecimal adviceId = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("ALLOCATEDAMT").equals(entries.getKey())) {
						allocatedAmt = (BigDecimal) entries.getValue();

						if (allocatedAmt == null) {
							allocatedAmt = BigDecimal.valueOf(0);

						}
					}

					if (("AMTINPROCESS").equals(entries.getKey())) {
						amtInProcess = (BigDecimal) entries.getValue();
						if (amtInProcess == null) {
							amtInProcess = BigDecimal.valueOf(0);

						}

					}

					if (("ORIGINALAMT").equals(entries.getKey()))

					{
						originalAmt = ((BigDecimal) entries.getValue());

						if (originalAmt == null) {

							originalAmt = BigDecimal.valueOf(0);

						}

					}
					if (("ID").equals(entries.getKey()))

					{
						adviceId = ((BigDecimal) entries.getValue());

					}

				}
				if (((allocatedAmt.add(amtInProcess)).compareTo(originalAmt) == 1) && (status == 'A')) {

					logList.add("Sum of allocated amt & amt in process is greater than original amt for Advice id : "
							+ adviceId);
					resultFlag = false;

				}
			}
			if (resultFlag) {
				logList.add("Sum of allocated amount and amount in process is not greater than original amount.");

			}

		} else {

			logList.add("Advice Details are not available.");
			// resultFlag=false;

		}

		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
