package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkReceivablePayableDtlMandNull implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub
		JXPathContext ctx = JXPathContext.newContext(context);
		int idLoanAccDtl=(int) ctx.getValue("/loan_account/ID", Integer.class);
		String statusLoanAccDtl= (String) ctx.getValue("/loan_account/STATUS", String.class);
		List<String> logList = new ArrayList<String>();
		List<Map<?,?>> recPayDtl = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		if(recPayDtl!=null){
			boolean returnFlag=true;
			Iterator<Map<?,?>> itr= recPayDtl.iterator();
			while(itr.hasNext()){
				Map<String,String> mValues= (Map<String, String>) itr.next();
				String bpTypeId=null;
				String chargeCode=null;
				String chargeCodeMstId=null;
				Date dueDate=null;
				String chargeMstId=null;
				String currencyMstid=null;
				String customerNum=null;
				BigDecimal loanId= new BigDecimal(0);
				BigDecimal originalAmt= new BigDecimal(0);
				BigDecimal recPayAmt= new BigDecimal(0);
				String recPayFlag=null;
				Date recPayDate=null;
				for(Map.Entry entries : mValues.entrySet()){
					if("BPTYPE_ID".equals(entries.getKey()))
						bpTypeId=  entries.getValue().toString();
					if("CHARGECODE".equals(entries.getKey()))
						chargeCode=  entries.getValue().toString();
					if("CHARGECODE_MST_ID".equals(entries.getKey()))
						chargeCodeMstId= entries.getValue().toString();
					if("DUEDATE".equals(entries.getKey()))
						dueDate= (Date) entries.getValue();
					if("CHARGE_MST_ID".equals(entries.getKey()))
						chargeMstId=  entries.getValue().toString();
					if("CURRENCY_MST_ID".equals(entries.getKey()))
						currencyMstid=  entries.getValue().toString();
					if("CUSTOMER_NO".equals(entries.getKey()))
						customerNum=  entries.getValue().toString();
					if("LOANID".equals(entries.getKey()))
						loanId= (BigDecimal) entries.getValue();
					if("ORIGINALAMT".equals(entries.getKey()))
						originalAmt= (BigDecimal) entries.getValue();
					if("RECEIVABLE_PAYABLE_AMT".equals(entries.getKey()))
						recPayAmt= (BigDecimal) entries.getValue();
					if("RECEIVABLE_PAYABLE_FLAG".equals(entries.getKey()))
						recPayFlag=  entries.getValue().toString();
					if("RECEIVABLE_PAYABLE_DATE".equals(entries.getKey()))
						recPayDate= (Date) entries.getValue();
				}
	//error//		if(loanId.compareTo(new BigDecimal(idLoanAccDtl)) && "A".equals(statusLoanAccDtl)){
					if(bpTypeId==null){
						logList.add("BP type Id is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(chargeCode==null){
						logList.add("Charge code is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(chargeCodeMstId==null){
						logList.add("Charge code mst id is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(dueDate==null){
						logList.add("Due date is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(chargeMstId==null){
						logList.add("Charge mst Id is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(currencyMstid==null){
						logList.add("Currency mst id is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(customerNum==null){
						logList.add("Customer number is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(originalAmt==null){
						logList.add("Original Amount is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(recPayAmt==null){
						logList.add("Receivable Payble amount is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(recPayFlag.isEmpty()){
						logList.add("Receivable Payble flag is empty for loan id: "+loanId);
						returnFlag=false;
					}
					if(recPayDate==null){
						logList.add("Receivable Payble date is empty for loan id: "+loanId);
						returnFlag=false;
					}	
				}
			}
			if(returnFlag){
				logList.add("No mandatory fields are found empty for loan id: "+idLoanAccDtl);
			}
			logger.setLog(logList);
			return returnFlag;
		}
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
