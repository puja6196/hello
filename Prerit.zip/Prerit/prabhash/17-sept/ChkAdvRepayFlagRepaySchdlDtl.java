package com.nucleus.tools.datasanitizer.lms;
/////////////////checked/////////////////
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkAdvRepayFlagRepaySchdlDtl implements RuleExecutor {
	
	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub
		JXPathContext ctx = JXPathContext.newContext(context);
		int idSubLoan=(int) ctx.getValue("/loan_account/ID", Integer.class);
		String statusSubLoan= (String) ctx.getValue("/loan_account/STATUS", String.class);
		List<String> logList = new ArrayList<String>();
		List<Map<?,?>> repaymentSchdlDetail = MVEL.eval("loan_account", context, List.class);
		if(repaymentSchdlDetail!=null){
			boolean returnFlag=true;
			Iterator<Map<?,?>> itr= repaymentSchdlDetail.iterator();
			while(itr.hasNext()){
				Map<String,String> mValues= (Map<String, String>) itr.next();
				String advRepayFlag=null;
				Integer loanId= new Integer(0);
				for(Map.Entry entry:mValues.entrySet()){
					if("ADVANCE_PREPAY_FLAG".equals(entry.getKey())){
						advRepayFlag=entry.getValue().toString();
					}
					if("LOANID".equals(entry.getKey())){
						loanId=(Integer) entry.getValue();
					}
						
				}
				if(advRepayFlag.equals("Y") || advRepayFlag.equals("N") || advRepayFlag.equals("B")){
					//do nothing
				}
				else
				{
					if("A".equals(statusSubLoan) && idSubLoan==loanId){
						logList.add("Advance Repay Flag is not 'Y' or 'N' or 'B' for loan id: "+idSubLoan);
						returnFlag=false;
					}
				}
				
				if(returnFlag)
				{
					logList.add("Advance Repay Flag is either 'Y' or 'n' or 'B' for loan id: "+idSubLoan);
				}
			}
			logger.setLog(logList);
			return returnFlag;
		}
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
