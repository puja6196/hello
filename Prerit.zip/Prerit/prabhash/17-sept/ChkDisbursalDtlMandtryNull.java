package com.nucleus.tools.datasanitizer.lms;
////////////////checked/////////////////
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkDisbursalDtlMandtryNull implements RuleExecutor {
	
	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<String>();
		List<Map<?,?>> disbursaldetails = MVEL.eval("loan_account.?disbursal_details", context, List.class);
		if(disbursaldetails!=null){
			boolean returnFlag=true;
			Iterator<Map<?,?>> itr= disbursaldetails.iterator();
			while(itr.hasNext()){
				Map<String,String> mValues= (Map<String, String>) itr.next();
				Integer id= new Integer(0);   //(int) ctx.getValue("/loan_account/disbursal_details/ID", Integer.class);
				String loanAccountNum= null;	//(int) ctx.getValue("/loan_account/disbursal_details/LOAN_ACCOUNT_NO", Integer.class);
				Integer currencyMstId= new Integer(0);	 //(int) ctx.getValue("/loan_account/disbursal_details/CURRENCY_MST_ID", Integer.class);
				BigDecimal loanDisbursalAmount = new BigDecimal(0);    //(BigDecimal) ctx.getValue("/loan_account/disbursal_details/DISBURSAL_AMT", BigDecimal.class);
				Date disbursalDate = null; 	//(Date) ctx.getValue("/loan_account/disbursal_details/DISBURSAL_DATE", Date.class);
				Integer disbursalNo = new Integer(0); 	//(int) ctx.getValue("/loan_account/disbursal_details/DISBURSAL_NO", Integer.class);
				BigDecimal disbursalRate= new BigDecimal(0);	//(BigDecimal) ctx.getValue("/loan_account/disbursal_details/DISBURSAL_RATE", BigDecimal.class);
				Date disbursalTxnDate = null;		//(Date) ctx.getValue("/loan_account/disbursal_details/DISBURSAL_TXN_DATE", Date.class);
				Integer loanId = new Integer(0);		//(int) ctx.getValue("/loan_account/disbursal_details/LOANID", Integer.class);
				String startInstlmntRecoverty=null;		//(Date) ctx.getValue("/loan_account/disbursal_details/START_INSTALLMENT_RECOVERY", Date.class);
				String disbursalStatus= null; // (char) ctx.getValue("/loan_account/disbursal_details/DISBURSAL_STATUS", Character.class);
				String txnType= null;		//(String) ctx.getValue("/loan_account/disbursal_details/TRANSACTION_TYPE", String.class);
				for(Map.Entry entry:mValues.entrySet()){
					if(("LOAN_ACCOUNT_NO").equals(entry.getKey()))
						loanAccountNum=entry.getValue().toString();
					if(("CURRENCY_MST_ID").equals(entry.getKey()))
						currencyMstId=(Integer) entry.getValue();
					if(("DISBURSAL_AMT").equals(entry.getKey()))
						loanDisbursalAmount=(BigDecimal) entry.getValue();
					if(("DISBURSAL_DATE").equals(entry.getKey()))
						disbursalDate=(Date) entry.getValue();
					if(("DISBURSAL_NO").equals(entry.getKey()))
						disbursalNo=(Integer) entry.getValue();
					if(("DISBURSAL_RATE").equals(entry.getKey()))
						disbursalRate=(BigDecimal) entry.getValue();
					if(("DISBURSAL_TXN_DATE").equals(entry.getKey()))
						disbursalTxnDate=(Date) entry.getValue();
					if(("START_INSTALLMENT_RECOVERY").equals(entry.getKey()))
						startInstlmntRecoverty=entry.getValue().toString();
					if(("DISBURSAL_STATUS").equals(entry.getKey()))
						disbursalStatus=entry.getValue().toString();
					if(("TRANSACTION_TYPE").equals(entry.getKey()))
						txnType=entry.getValue().toString();
					if(("ID").equals(entry.getKey()))
						id=(Integer) entry.getValue();
				}
				if("A".equals(disbursalStatus)){
					if(loanAccountNum==null){
						logList.add("Loan Account Number is empty for loan id: "+id);
						returnFlag=false;
					}
					if(currencyMstId==null){
						logList.add("Currency Mst Id is empty for loan id: "+id);
						returnFlag=false;
					}
					if(loanDisbursalAmount==null){
						logList.add("Loan Disbursal Amount is empty for loan id: "+id);
						returnFlag=false;
					}
					if(disbursalDate==null){
						logList.add("Loan Disbursal Date is empty for loan id: "+id);
						returnFlag=false;
					}
					if(disbursalNo==null){
						logList.add("Loan Disbursal Number is empty for loan id: "+id);
						returnFlag=false;
					}
					if(disbursalRate==null){
						logList.add("Loan Disbursal Rate is empty for loan id: "+id);
						returnFlag=false;
					}
					if(disbursalTxnDate==null){
						logList.add("Disbursal Txn Date is empty for loan id: "+id);
						returnFlag=false;
					}
					if(startInstlmntRecoverty==null){
						logList.add("Start Installment Recovery is empty for loan id: "+id);
						returnFlag=false;
					}
					if(disbursalStatus==null){
						logList.add("Disbursal Status is empty for loan id: "+id);
						returnFlag=false;
					}
					if(txnType==null){
						logList.add("Transaction Type is empty for loan id: "+id);
						returnFlag=false;
					}
				}
				
			}
			if(returnFlag){
				logList.add("No mandatory field is empty for loan id: ");
			}
			logger.setLog(logList);
			return returnFlag;
		}
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
