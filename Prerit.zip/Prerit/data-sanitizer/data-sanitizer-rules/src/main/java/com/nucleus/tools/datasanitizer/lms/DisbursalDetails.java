package com.nucleus.tools.datasanitizer.lms;

public class DisbursalDetails {

}
