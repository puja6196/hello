package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub
		 List<String> logList = new ArrayList<String>();
		 JXPathContext ctx = JXPathContext.newContext(context);
		 char autoManualClassifyFlag= (char) ctx.getValue("/LMS_LOANACCOUNT_DTL/AUTO_MANUAL_CLASSIFY_FLAG", Character.class);
		 int assetClassMstId= (int) ctx.getValue("/LMS_LOANACCOUNT_DTL/ASSET_CLASS_MST_ID", Integer.class);
		 String lastManualAssetMstId= (String) ctx.getValue("/LMS_LOANACCOUNT_DTL/LAST_MANUAL_ASSET_CLASS_MST_ID", String.class);
		 int count=0;
		 if(autoManualClassifyFlag=='M' && assetClassMstId!=1 && lastManualAssetMstId.isEmpty()){
			 count+=count;
		 }
		 if(count==0){
			 // do nothing
		 }
		 else{
			 logList.add("Last mannual asset class mst id is null for "+lastManualAssetMstId+"where asset class mst id= "+assetClassMstId);
		 }
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
