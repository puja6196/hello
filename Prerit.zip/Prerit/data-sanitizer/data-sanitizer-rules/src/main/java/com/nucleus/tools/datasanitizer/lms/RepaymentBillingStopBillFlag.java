package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RepaymentBillingStopBillFlag implements RuleExecutor{
	
	@Override
	public boolean execute(RootObject context,Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		Date businessDate = (Date) ctx.getValue("/loan_account/BUSINESS_DATE", Date.class);
		String stopBillFlag = (String) ctx.getValue("/loan_account/STOP_BILL_FLAG", String.class);
		List<String> logList = new ArrayList<String>();
		List<Map<?,?>> repaymentDetails = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		boolean returnFlag=true;
		
		if ("N".equalsIgnoreCase(stopBillFlag)){
		if(repaymentDetails != null){
			
			Iterator<Map<?, ?>> it = repaymentDetails.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				
				int instNumber = 0;
				Date dueDate = new Date();
				String billFlag=null;
				for (Map.Entry entries : mapValues.entrySet()){

					if(("DUEDATE").equals(entries.getKey()))
						dueDate	 =(Date) entries.getValue();
					if(("BILLED_FLAG").equals(entries.getKey()))
						billFlag	 = (String) entries.getValue();
						if(("INSTALMENT_NUMBER").equals(entries.getKey()))
						instNumber =  ((BigDecimal) entries.getValue()).intValue();
						
						
				}
				if ( dueDate.before(businessDate) &&  "Y".equalsIgnoreCase(billFlag) ){
					//do nothing
					
			}
				else if (dueDate.before(businessDate) &&  "N".equalsIgnoreCase(billFlag)){
					SimpleDateFormat format1 = new SimpleDateFormat("dd/MM/yyyy");
					logList.add("Installment # "+instNumber+" with DueDate : "+format1.format(dueDate) +" is not billed.");
					returnFlag=false;
				}
			else{
				
				//DO NOTHING
			}
				
			} 
			
	if (returnFlag)
		logList.add("All the installments with due dates less than the business date are billed.");

				
			}else{
				returnFlag=false;
				logList.add("Repayment Schedule not available.");
			}
		}else
		{
			logList.add("Stop Bill Flag is 'Y', hence this rule is not applicable.");
		}
		logger.setLog(logList);
		return returnFlag;
		}
	
	@Override
	public boolean shouldExecute(RootObject context) {
		return true;
	}

}
