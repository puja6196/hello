package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class BucketDpdDtlYrNull implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<String> logList = new ArrayList<String>();
		List<Map<?,?>> noOfRecorrdsInLmsBucket = MVEL.eval("loan_account.?bucket_dpd_details", context, List.class);
		BigDecimal year = new BigDecimal(0); 
		BigDecimal id =new BigDecimal(0);
		boolean resultFlag=true;
		if(noOfRecorrdsInLmsBucket!=null){
       Iterator<Map<?, ?>> it = noOfRecorrdsInLmsBucket.iterator();
		while (it.hasNext()){
			Map<String,String> mapValues = (Map<String, String>) it.next();
			for (Map.Entry entries : mapValues.entrySet()){
				if (("ID").equals(entries.getKey()))
					id = (BigDecimal) entries.getValue();
				if (("YEAR").equals(entries.getKey()))
					year = (BigDecimal) entries.getValue();   
			}
			if(year==null){
				logList.add("Year is Blank for Bucket Dpd Id: "+id);
				resultFlag= false;
			}
		}
		}
		else{
		logList.add("No data available in Bucket Dpd details");
		resultFlag= false;
	}
		if(resultFlag)
			logList.add("Year is not blank for Bucket Dpd Id :"+id);
		logger.setLog(logList);
		return resultFlag;
	}
	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
