package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class MisDtlMisMatchInAddTdsAmt implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		BigDecimal addTdsAmt = new BigDecimal(0);
		BigDecimal recievablePaybleAmt = new BigDecimal(0);
		BigDecimal loanAcctNo = new BigDecimal(0);
		BigDecimal misLoanAcctNo = new BigDecimal(0);
		BigDecimal chargeCode = new BigDecimal(0);
		BigDecimal chargeCode378 = new BigDecimal(378);
		BigDecimal sumrecievalblePayableAmt = new BigDecimal(0);
		BigDecimal vapId = new BigDecimal(0);
		BigDecimal vapId0 = new BigDecimal(0);
		String adviceStatus = null;
		boolean resultFlag = true;
		List<Map<?, ?>> adviceDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		JXPathContext ctx = JXPathContext.newContext(context);
		try {
			misLoanAcctNo = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/LOAN_ACCOUNT_NO",
					BigDecimal.class);
			loanAcctNo = (BigDecimal) ctx.getValue("/loan_account/LOAN_ACCOUNT_NO", BigDecimal.class);
			addTdsAmt = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/ADDITIONAL_TDS_AMT",
					BigDecimal.class);
		} catch (Exception e) {
			logList.add("Exception occured while retrieving data from Loan Account and Loan Mis Details");
		}
		Iterator<Map<?, ?>> it = adviceDtl.iterator();
		while (it.hasNext()) {
			Map<String, String> mapValues = (Map<String, String>) it.next();
			for (Map.Entry entries : mapValues.entrySet()) {
				try {
					if (("CHARGECODE").equals(entries.getKey()))
						chargeCode = (BigDecimal) entries.getValue();
					if (("RECEIVABLE_PAYABLE_AMT").equals(entries.getKey()))
						recievablePaybleAmt = (BigDecimal) entries.getValue();
					if (("STATUS").equals(entries.getKey()))
						adviceStatus = (String) entries.getValue();
					if (("VAPID").equals(entries.getKey()))
						vapId = (BigDecimal) entries.getValue();
				} catch (Exception e) {
					logList.add("Exception occured while retrieving data from Advice Details");
				}
			}
			if ((loanAcctNo.compareTo(misLoanAcctNo) == 0) && ("A".equals(adviceStatus))
					&& (chargeCode378.compareTo(chargeCode) == 0)) {
				sumrecievalblePayableAmt = sumrecievalblePayableAmt.add(recievablePaybleAmt);

			}
		}
		if (sumrecievalblePayableAmt == null)
			sumrecievalblePayableAmt = BigDecimal.ZERO;
		if (addTdsAmt == null)
			addTdsAmt = BigDecimal.ZERO;
		if (vapId.compareTo(vapId0) == 0) {
			if (addTdsAmt.compareTo(sumrecievalblePayableAmt) == 0) {
				// do nothing
			} else {
				resultFlag = false;
				logList.add("Loan Mis details having mismatch in Additional Tds Amount");
			}
		}
		if (resultFlag)
			logList.add("Loan Mis details having No mismatch in Additional Tds Amount");

		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject logger) {
		// TODO Auto-generated method stub
		return true;
	}

}
