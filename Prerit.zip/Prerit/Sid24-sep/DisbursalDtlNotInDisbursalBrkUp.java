package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalDtlNotInDisbursalBrkUp implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> lmsDistbursalBreakupDetails = MVEL
				.eval("loan_account.?disbursal_details.?disbursal_details_breakup", context, List.class);
		List<String> logList = new ArrayList<String>();
		BigDecimal disbursalAmt = new BigDecimal(0);
		BigDecimal disbursalBrkUpAmt = new BigDecimal(0);
		BigDecimal sumDisbursalBrkUpAmt = new BigDecimal(0);
		String disbursalStatus = null;
		String disbursalBrkUpStatus = null;
		String loanAcctStatus = null;
		boolean resultFlag = true;
		JXPathContext ctx = JXPathContext.newContext(context);
		try {
			disbursalAmt = (BigDecimal) ctx.getValue("/loan_account/disbursal_details/DISBURSAL_AMT", BigDecimal.class);
			disbursalStatus = (String) ctx.getValue("/loan_account/disbursal_details/DISBURSAL_STATUS", String.class);
			loanAcctStatus = (String) ctx.getValue("/loan_account/STATUS", String.class);
		} catch (Exception e) {
			logList.add("Exception occured while retrieving data from Disbursal Details");
		}
		Iterator<Map<?, ?>> it = lmsDistbursalBreakupDetails.iterator();
		if (disbursalAmt == null)
			disbursalAmt = BigDecimal.ZERO;
		
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					try {
						if (("DISBURSAL_STATUS").equals(entries.getKey()))
							disbursalBrkUpStatus = (String) entries.getValue();
						if (("DISBURSAL_AMT").equals(entries.getKey()))
							disbursalBrkUpAmt = (BigDecimal) entries.getValue();
						if (disbursalBrkUpAmt == null)
							disbursalBrkUpAmt = BigDecimal.ZERO;
					} catch (Exception e) {
						logList.add("Exception occured while Retrieving data from DisbursalBreakUp Detail");
					}
				}
				if ("A".equals(disbursalBrkUpStatus)) {
					sumDisbursalBrkUpAmt = sumDisbursalBrkUpAmt.add(disbursalBrkUpAmt);
				}

			}
			if (("A".equals(disbursalStatus)) && ("A".equals(loanAcctStatus))
					&& (disbursalAmt.compareTo(sumDisbursalBrkUpAmt) == 0)) {
				// do nothing
			} else {
				logList.add("Disbursal Details does not exist in DisbursalBreakup Details");
				resultFlag = false;
			}

		if (resultFlag)
			logList.add("Disbursal Details does exist in DisbursalBreakup Details");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
