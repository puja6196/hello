package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TermHdrNotInTermDtl implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> lmsTerminationHdr = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		List<Map<?,?>> lmsTerminationDtl = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		BigDecimal termHdrLoanId=new BigDecimal(0);
		BigDecimal termDtlLoanId=new BigDecimal(0);
		BigDecimal termHdrId=new BigDecimal(0);
		BigDecimal termDtlId=new BigDecimal(0);
		boolean resultFlag=true;
				Iterator<Map<?, ?>> it = lmsTerminationHdr.iterator();
				while (it.hasNext()) {
					Map<String, String> mapValues = (Map<String, String>) it.next();
					for (Map.Entry entries : mapValues.entrySet()) {
						try{
							if (("LOANID").equals(entries.getKey()))
								termHdrLoanId = (BigDecimal) entries.getValue();
							if(("ID").equals(entries.getKey()))
								termHdrId=(BigDecimal)entries.getValue();
							
							if(("termination_dtl_details").equals(entries.getKey()))
								lmsTerminationDtl=(List<Map<?, ?>>) entries.getValue();
							Iterator<Map<?, ?>> itIn = lmsTerminationDtl.iterator();
							while (itIn.hasNext()) {
								Map<String, String> mapValue = (Map<String, String>) itIn.next();
								for (Map.Entry entry : mapValue.entrySet()){
								if(("LOANID").equals(entry.getKey()))
									termDtlLoanId=(BigDecimal)entry.getValue();
								if(("ID").equals(entry.getKey()))
									termDtlId=(BigDecimal)entry.getValue();
								}	
							}
						}
						catch(Exception e){
							logList.add("Exception occured while retrieving data from Termination Hdr and termination Details");
						}
					}
					  if(termDtlLoanId.compareTo(termHdrLoanId)==0){
					//do nothing
						}
						else{
							logList.add("LMS termionation Hdr not In Termination Dtl for Termination Hdr ID:"+termHdrId+"And for Termination Details Id:"+termDtlId);
							resultFlag=false;
						}
     
					
				}
				
				
	if(resultFlag)
		logList.add("Lms Termination Hdr Available In Lms Termination Details ");
    logger.setLog(logList);	
	return resultFlag;
	}
		
	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
