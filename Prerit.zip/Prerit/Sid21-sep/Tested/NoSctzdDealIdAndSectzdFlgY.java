package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.JXPathContext;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class NoSctzdDealIdAndSectzdFlgY implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		String securitizedFlag = null;
		BigDecimal securitizedDealId= new BigDecimal(0);
		BigDecimal loanId= new BigDecimal(0);
		List<String> logList = new ArrayList<String>();
	    boolean resultFlag=true; 
		
		try{
			securitizedFlag = (String) ctx.getValue("/loan_account/SECURITIZED_FLAG", String.class);
			 securitizedDealId = (BigDecimal) ctx.getValue("/loan_account/SECURITIZED_DEALID", BigDecimal.class);
			 loanId = (BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
			 
		}
		catch(Exception e){
			
		}
		if((securitizedDealId==null)&&("Y".compareTo(securitizedFlag)==0)){
			logList.add("LMS loan Account where securitized Deal Id is null and Flag is 'Y'where loan Id is :"+loanId);
			resultFlag=false;
		}
		
		if(resultFlag){
			logList.add("Records in LMS loan Account where securitized Deal Id is not null or Flag is not 'Y' where loan Id is:"+loanId);
		
		}
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject logger) {
		// TODO Auto-generated method stub
		return true;
	}

}
