package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RecdPrinAmtNotEqualsSumPrinRcvd implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> recievablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		JXPathContext ctx = JXPathContext.newContext(context);
		boolean resultFlag=true;
		BigDecimal recordPrinAmt = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/RECD_PRIN_AMT", BigDecimal.class);
		BigDecimal chargeCode=new BigDecimal(0);
		String status=null;
		BigDecimal vapId=new BigDecimal(0);
		BigDecimal adviceLoanId=new BigDecimal(0);
		BigDecimal valReplacement=new BigDecimal(0);
		BigDecimal prinCompRecieved=new BigDecimal(0);	
		if(recievablePayableDtl!=null){
			Iterator<Map<?, ?>> it = recievablePayableDtl.iterator();
            while (it.hasNext()) {
                    Map<String, String> mapValues = (Map<String, String>) it.next();
                    for (Map.Entry entries : mapValues.entrySet()){
                    	try{
                    		if (("LOANID").equals(entries.getKey()))
                        		adviceLoanId = (BigDecimal)entries.getValue();
    						if (("CHARGECODE").equals(entries.getKey()))
    							chargeCode =(BigDecimal) entries.getValue();
    						if (("VAPID").equals(entries.getKey()))
    							vapId = (BigDecimal) entries.getValue();
    						if (("STATUS").equals(entries.getKey()))
    							status = (String) entries.getValue();
    						if (("PRINCOMP_RECEIVED").equals(entries.getKey()))
    							prinCompRecieved = (BigDecimal)entries.getValue();
    						if(prinCompRecieved==null)
    							prinCompRecieved=valReplacement;
    						
                    	}
                    	catch(Exception e){
                    		logList.add("Missing Fields in in Advice details causing NullPointer Exception");
                    	}
                    }
                	if((("A".compareTo(status)==0)&&(chargeCode.compareTo(chargeCode)==0)&&(vapId.compareTo(vapId)==0))){
                		prinCompRecieved=prinCompRecieved.add(prinCompRecieved);
					}
                	
            
		}
            if((recordPrinAmt.compareTo(prinCompRecieved)==1)||(recordPrinAmt.compareTo(prinCompRecieved)==-1)){
 				logList.add("Records having Recd Prin Amount equals to sum of Prin Components Recieved for Advice Id:"+adviceLoanId);
 				resultFlag=false;
 			}
           
           	
	}
		else{
			logList.add("No data available in Advice Detail");
			resultFlag=false;
		}
		if(resultFlag)
			logList.add("Records having Recd_Int_Amount equals not to sum of Prin Components Recieved for Advice Id:"+adviceLoanId);
		logger.setLog(logList);
		return resultFlag;
	}
	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
