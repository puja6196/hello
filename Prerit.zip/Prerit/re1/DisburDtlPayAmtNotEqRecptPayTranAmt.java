package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisburDtlPayAmtNotEqRecptPayTranAmt implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{   
		 
		 
		 List<Map<?,?>> disbPaymntDtls= MVEL.eval("loan_account.?disbursal_paymnet_details", context, List.class);
		 List<Map<?,?>> paymntDtls= MVEL.eval("loan_account.?payment_details", context, List.class);
		
		 List<String> logList = new ArrayList<String>();
		 boolean resultFlag = true;
		 if(disbPaymntDtls!=null)
		 {
		 
			 Iterator<Map<?, ?>> it = disbPaymntDtls.iterator();
        while (it.hasNext()) 
                              {
                            Map<String, String> mapValues = (Map<String, String>) it.next();
		                    BigDecimal transctnAmt = new BigDecimal(0);  
		                    BigDecimal paymntAmt=new BigDecimal(0);
		                    BigDecimal loanId=new BigDecimal(0);
		                    BigDecimal payDtlVapid=new BigDecimal(0);
		
		                             for (Map.Entry entries : mapValues.entrySet()) 
		                                  {
		                                         if (("PAYMENT_AMOUNT").equals(entries.getKey()))
		                    	                 paymntAmt = (BigDecimal) entries.getValue();
		                       
                              
                              
                                                 if (("payment_details").equals(entries.getKey()))
                            	                 paymntDtls = (List<Map<?, ?>>) entries.getValue();
                              
                                                 Iterator<Map<?, ?>> itr = paymntDtls.iterator();
                                                 while (itr.hasNext()) 
                                                     {
                                                          Map<String, String> mapValue = (Map<String, String>) itr.next();
                              

                            		                      for (Map.Entry entrie : mapValue.entrySet()) 
                            		                          {
                            			                       if (("TRANSACTION_AMOUNT").equals(entries.getKey()))
                                      	                       transctnAmt = (BigDecimal) entries.getValue();
                            			
                            			                       if (("VAPID").equals(entries.getKey()))
                            			                    	   payDtlVapid = (BigDecimal) entries.getValue();
                            			

              		                                         if (("ID").equals(entries.getKey()))
                                 				                  loanId = (BigDecimal) entries.getValue();
                            			
                            		                           }   
                              
                                                     }
                              
		                                  }
                                         if((paymntAmt.compareTo(transctnAmt)!=0)&&(payDtlVapid.compareTo(new BigDecimal(0))==0)&&(payDtlVapid.compareTo(new BigDecimal(0))==0))
                                        {
                            	  
                            	             logList.add("Data from LMS_DISBURSAL_PAYMENT_DTL where  payment amount is not equal to receipt payment transaction amount for Loan Id:"+loanId);
                            	             resultFlag=false;
                            	  
                            	  
                                        }
                              
                              }                            
		                                  
		                             if(resultFlag)
		                     		{
		                     			 logList.add("LMS_DISBURSAL_PAYMENT_DTL table has  payment amount   equals to receipt payment transaction amount.");
		                     			
		                     			
		                     		}
                              
                              
		
                              
     	}
		 else
		 {
			 
			logList.add("No record available in Disbursal Payment Detail.") ;
			resultFlag=false;
			 
			 
		 }
        
       
       
   
        
        
		logger.setLog(logList);
		return resultFlag;
		
		
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
