package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanRepAdvPrepayFlagNotYNB implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		   JXPathContext ctx = JXPathContext.newContext(context);
		   List<String> logList = new ArrayList<String>();
		   BigDecimal loanId=(BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
		   String loanAccStatus = (String) ctx.getValue("/loan_account/STATUS", String.class);
		   Boolean resultFlag=true;
		   List<Map<?,?>> loanRepayment = MVEL.eval("loan_account.?loan_repayment", context, List.class);

	         if(loanRepayment!=null)
	               {
						
		              Iterator<Map<?, ?>> it = loanRepayment.iterator();
		              while (it.hasNext())
							
		                 {
			                  Map<String,String> mapValues = (Map<String, String>) it.next();
			
			                 String advanceRepayFlag=null;
			                 
			                      for (Map.Entry entries : mapValues.entrySet())
			                            {
				                          if(("ADVANCE_PREPAY_FLAG").equals(entries.getKey()))
				                                 {
				                        	  advanceRepayFlag=(String) entries.getValue().toString();
					
				                                 }
			                            }
			                      if((advanceRepayFlag!="Y")||(advanceRepayFlag!="N")||(advanceRepayFlag!="B")&&(loanAccStatus=="A"))
			                      {
			                    	  
			                      resultFlag=false;
			                      logList.add("ADVANCE_PREPAY_FLAG is not in ('Y','N','B') in LMS_REPAYSCHEDULE_DTL Table for Loan Id:"+loanId);
			                      
			                      
			                      }
			                      }
		              if(resultFlag)
		              {
		            	  logList.add("ADVANCE_PREPAY_FLAG is  in ('Y','N','B') in LMS_REPAYSCHEDULE_DTL Table for Loan Id:"+loanId);
		            	  
		            	  
		              }
	               }
	         else
	         {
	        	 
	        	 logList.add("No data available in Loan Repayment");
	        	 resultFlag=false;
	        	 
	         }

	logger.setLog(logList);
	return resultFlag;



	    
		
	}

	@Override
	public boolean shouldExecute(RootObject arg0) 
	{
		// TODO Auto-generated method stub
		return false;
	}

}
