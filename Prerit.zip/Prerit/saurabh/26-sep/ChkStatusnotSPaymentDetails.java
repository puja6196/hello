package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkStatusnotSPaymentDetails implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		List<Map<?, ?>> paymentDetails = MVEL.eval("loan_account.?payment_details", context, List.class);
		if (paymentDetails != null) {
			Iterator<Map<?, ?>> it = paymentDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				BigDecimal receiptpayment_type = new BigDecimal(0);
				String mc_status = null;
				String reject_cancel_delete_indicator =null;
				String status = null;
				BigDecimal receiptpayment_detailsval = new BigDecimal(50021);
				for (Map.Entry entries : mapValues.entrySet()) {
					if(("RECEIPTPAYMENT_TYPE").equals(entries.getKey()))
						receiptpayment_type = (BigDecimal) entries.getValue();
					if(("MC_STATUS").equals(entries.getKey()))
						mc_status = (String) entries.getValue();
					if(("REJECT_CANCEL_DELETE_INDICATOR").equals(entries.getKey()))
						reject_cancel_delete_indicator = (String) entries.getValue();
					if(("STATUS").equals(entries.getKey()))
						status = (String) entries.getValue();
				}
				if((receiptpayment_type.compareTo(receiptpayment_detailsval)==0) && ("A".equalsIgnoreCase(mc_status)) && (reject_cancel_delete_indicator==null) && (status!="S"))
				{
					logList.add("Records present in payment details where status is not equal to s for authorized disbursal payment chaque.");
					returnFlag = false;
				
				}
				
				
				
			}
			if(returnFlag)
			{
				logList.add("Records present in payment details where status is  equal to S for authorized disbursal payment chaque.");
			}
		}else{
			logList.add("Payment details are not available.");
			returnFlag=false;
			
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}
	

}
