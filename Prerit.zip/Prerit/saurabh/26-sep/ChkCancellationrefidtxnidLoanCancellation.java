package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkCancellationrefidtxnidLoanCancellation implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> cancellationdetails = MVEL.eval("loan_account.?cancellation_hdr_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if(cancellationdetails!=null){
			Iterator<Map<?, ?>> it = cancellationdetails.iterator();
			while(it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>)it.next();
			      BigDecimal cancellation_ref_id = new BigDecimal(0);
			      Date transaction_date = null;
			      BigDecimal loanid = new BigDecimal(0);
			      
			      for (Map.Entry entries : mapValues.entrySet()) {
			    	  if(("CANCELLATION_REF_ID").equals(entries.getKey()))
			    		  cancellation_ref_id = (BigDecimal) entries.getValue();
			    	  if(("TRANSACTION_DATE").equals(entries.getKey()))
			    		  transaction_date = (Date) entries.getValue();
			    	  if(("LOANID").equals(entries.getKey()))
			    		  loanid = (BigDecimal) entries.getValue();
			      }
			      if(cancellation_ref_id==null){
			    	  logList.add("Cancellation ref id is null in Loan Cancellation for loan id :"+loanid);
			    	  resultFlag=false;
			      }
			      if(transaction_date==null){
			    	  logList.add("Transaction date is null in Loan Cancellation for Loan id :"+loanid);
			          resultFlag=false;
			      }
			    	  
			}
			if(resultFlag){
				logList.add("Cancellation ref id , Transaction date are not null in Loan Cancellation .");
			}
			
		}else{
			logList.add("Loan Cancellation Details are not avilable.");
			resultFlag=false;
		}
		logger.setLog(logList);
		return  resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return  true;
	}

}
