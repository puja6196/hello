package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkRecordsLoanMisnoLoan implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal id = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/ID", BigDecimal.class);
		String loan_account_no = (String) ctx.getValue("/loan_account/loan_mis_details/LOAN_ACCOUNT_NO", String.class);
		BigDecimal tenant_id = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/TENANT_ID", BigDecimal.class);
		BigDecimal loan_mis_id = (BigDecimal) ctx.getValue("/loan_account/LOAN_MIS_ID", BigDecimal.class);
		String loan_account_no1 = (String) ctx.getValue("/loan_account/LOAN_ACCOUNT_NO", String.class);
		BigDecimal tenant_id1 = (BigDecimal) ctx.getValue("/loan_account/TENANT_ID", BigDecimal.class);

		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;

		if ((loan_mis_id.compareTo(id) == 0) && (loan_account_no.equalsIgnoreCase(loan_account_no1))
				&& (tenant_id.compareTo(tenant_id1) == 0)) {
			// do nothing

		} else {
			logList.add("Records are not present in loan mis details. ");
			returnFlag = false;
		}

		if (returnFlag) {
			logList.add("Records are present in Loan Mis Details.");
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
