package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class OriginalChequeCancelledLoanAdvice implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		List<Map<?, ?>> advicedetails = MVEL.eval("loan_account.?advice_details", context, List.class);
		List<Map<?, ?>> paymentdetails = MVEL.eval("loan_account.?payment_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		String status = null;

		BigDecimal chargecode = new BigDecimal(0);
		BigDecimal receivable_payable_flag = new BigDecimal(0);
		BigDecimal id = new BigDecimal(0);
		BigDecimal receiptpaymentid = new BigDecimal(0);
		String statuspayment = null;
		BigDecimal chargecodeval = new BigDecimal(37);
		BigDecimal receivable_payable_flagval = new BigDecimal(61099);
		if (advicedetails != null || paymentdetails != null) {
			Iterator<Map<?, ?>> it = advicedetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("STATUS").equals(entries.getKey()))
						status = entries.getValue().toString();
					if (("CHARGECODE").equals(entries.getKey()))
						chargecode = (BigDecimal) entries.getValue();
					if (("RECEIVABLE_PAYABLE_FLAG").equals(entries.getKey()))
						receivable_payable_flag = (BigDecimal) entries.getValue();
					if (("RECEIPTPAYMENTID").equals(entries.getKey()))
						receiptpaymentid =  (BigDecimal) entries.getValue();
					if (("payment_details").equals(entries.getKey()))
						paymentdetails = (List<Map<?, ?>>) entries.getValue();
					Iterator<Map<?, ?>> itIn = paymentdetails.iterator();
					while (itIn.hasNext()) {
						Map<String, String> mapValue = (Map<String, String>) itIn.next();
						for (Map.Entry entry : mapValue.entrySet()) {
							if (("ID").equals(entry.getKey()))
								id = (BigDecimal) entry.getValue();
							if (("STATUS").equals(entry.getKey()))
								statuspayment = entry.getValue().toString();
						}
					}

				}

				if ((id==receiptpaymentid) && ("X".equalsIgnoreCase(statuspayment))) {
					if ("A".equalsIgnoreCase(status) && (chargecode.compareTo(chargecodeval) == 0)
							&& (receivable_payable_flag.compareTo(receivable_payable_flagval) == 0)) {
						// do nothing

					} else {
						logList.add(
								"Status is A and Chargecode is 37 and Receivable_payable is 61099 are not equal in Advice details.");
						returnFlag = false;
					}
				} else {
					logList.add("Receiptpaymentid is equal and status is X are not in payment details.");
					returnFlag=false;
				}

				System.out.println("status " + status);
				System.out.println("chargecode " + chargecode);
				System.out.println("receivable_payable_flag " + receivable_payable_flag);
				System.out.println("receiptpaymentid " + receiptpaymentid);
				System.out.println("id " + id);
				System.out.println("statuspayment " + statuspayment);
			}
			if (returnFlag) {
				logList.add("Original Cheque is cancelled .");
			}

		} else {
			logList.add("Advice details and Payment details are not avilable.");
			returnFlag = false;
		}

		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
