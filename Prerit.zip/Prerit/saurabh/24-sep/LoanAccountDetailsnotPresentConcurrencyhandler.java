package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAccountDetailsnotPresentConcurrencyhandler implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal id = (BigDecimal) ctx.getValue("loan_account/ID", BigDecimal.class);
		BigDecimal loanid = (BigDecimal) ctx.getValue("loan_account/concurrency_details/LOANID",BigDecimal.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		
				if (((id).compareTo(loanid) == -1) || ((id).compareTo(loanid) == 1)) {
					logList.add("Loan account datails are not present in concurrency handler for loan id :"+loanid);
					returnFlag = false;
					
				} 
			
			if (returnFlag) {
				logList.add("Lann account details are  present in concurrency handler.");
			}
            
		
	    logger.setLog(logList);
	    return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
