package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFieldsLoanCancellation implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> cancellationdetails = MVEL.eval("loan_account.?cancellation_hdr_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if(cancellationdetails!=null){
			Iterator<Map<?, ?>> it = cancellationdetails.iterator();
			while(it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>)it.next();
			      BigDecimal cancellation_reason_id = new BigDecimal(0);
			      String cancellation_type = null;
			      String mc_status = null;
			      BigDecimal txn_branchid = new BigDecimal(0);
			      String cancellation_txn_type = null;
			      String loan_account_no = null;
			      BigDecimal loanid = new BigDecimal(0);
			      BigDecimal vapid = new BigDecimal(0);
			      BigDecimal vapidval = BigDecimal.ZERO;
			      for (Map.Entry entries : mapValues.entrySet()) {
			    	  if(("CANCELLATION_REASON_ID").equals(entries.getKey()))
			    		  cancellation_reason_id = (BigDecimal) entries.getValue();
			    	  if(("CANCELLATION_TYPE").equals(entries.getKey()))
			    		  cancellation_type = entries.getValue().toString();
			    	  if(("MC_STATUS").equals(entries.getKey()))
			    		  mc_status = entries.getValue().toString();
			    	  if(("TXN_BRANCHID").equals(entries.getKey()))
			    		  txn_branchid = (BigDecimal) entries.getValue();
			    	  if(("CANCELLATION_TXN_TYPE").equals(entries.getKey()))
			    		  cancellation_txn_type = (String) entries.getValue();
			    	  if(("LOAN_ACCOUNT_NO").equals(entries.getKey()))
			    		  loan_account_no = (String) entries.getValue();
			    	  if(("LOANID").equals(entries.getKey()))
			    		  loanid = (BigDecimal) entries.getValue();
			    	  if(("VAPID").equals(entries.getKey()))
			    		  vapid=(BigDecimal) entries.getValue();
			    	}
			         if(vapid.compareTo(vapidval)==0){
			        if(cancellation_reason_id==null)
			        {
			        	logList.add("Cancellation reason id is null in Loan Cancellation for loan id :"+loanid);
			        	resultFlag=false;
			        }
			        if(cancellation_type==null)
			        {
			        	logList.add("Cancellation type is null in Loan Cancellation for loan id :"+loanid);
			        	resultFlag=false;
			        }
			        if(mc_status==null)
			        {
			        	logList.add("Mc Status is null in Loan Cancellation for loan id :"+loanid);
			            resultFlag=false;
			        }
			        if(txn_branchid==null)
			        {
			        	logList.add("Transaction branchid is null in Loan Cancellation for loan id:"+loanid);
			            resultFlag=false;
			        }
			        if(cancellation_txn_type==null){
			        	logList.add("Cancellation transaction type is null in Loan Cancellation for loan id :"+loanid);
			            resultFlag=false;
			        }
			        if(loan_account_no==null){
			        	logList.add("Loan account no is null in Loan Cancellation for loan id :"+loanid);
			        	resultFlag=false;
			        }
			        if(loanid==null){
			        	logList.add("Loan id is null in Loan Cancellation for loan id :"+loanid);
			        	resultFlag=false;
			        }
			        }
			}
			if(resultFlag){
				logList.add("Cancellation reason id , Cancellation type , MC status , Transaction Branchid , Cancellation Transaction type , Loan account no , Loanid  are not null in Loan Cancellation .");
			}
		}else{
			logList.add("Loan Cancellation Details are not avilable.");
			 resultFlag=false;
			 
		}
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
