package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkLoanidPresentLoanTemination implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> lmsTerminationHdr = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		List<Map<?, ?>> lmsTerminationDtl = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		BigDecimal terminationdtlloandid = new BigDecimal(0);
		BigDecimal terminationhdrloanid = new BigDecimal(0);
		BigDecimal vapid = new BigDecimal(0);
		BigDecimal vapidval = BigDecimal.ZERO;
		boolean resultFlag = true;
		if (lmsTerminationDtl != null && lmsTerminationHdr != null) {
			Iterator<Map<?, ?>> it = lmsTerminationDtl.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("LOANID").equals(entries.getKey()))
						terminationdtlloandid = (BigDecimal) entries.getValue();
					if(("VAPID").equals(entries.getKey()))
						vapid = (BigDecimal) entries.getValue();
					if (("termination_hdr_details").equals(entries.getKey()))
						lmsTerminationHdr = (List<Map<?, ?>>) entries.getValue();
					Iterator<Map<?, ?>> itIn = lmsTerminationHdr.iterator();
					while (itIn.hasNext()) {
						Map<String, String> mapValue = (Map<String, String>) itIn.next();
						for (Map.Entry entry : mapValue.entrySet()) {
							if (("LOANID").equals(entry.getKey()))
								terminationhdrloanid = (BigDecimal) entry.getValue();
						}
					}

				}
				if(vapid.compareTo(vapidval)==0)
				{
				if (terminationdtlloandid.compareTo(terminationhdrloanid) == 0) {
					// do nothing
				} else {
					logList.add("Loan Termination Details are not avilable in Loan Termination Header.");
					resultFlag = false;
				}
				}
			}
			if (resultFlag) {
				logList.add("Loan Termination Details are not avilable in Loan Termination Header.");
			}
		} else {
			logList.add("Loan Termination details and Loan Termination Header are not avilable.");
			resultFlag = false;
		}
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
