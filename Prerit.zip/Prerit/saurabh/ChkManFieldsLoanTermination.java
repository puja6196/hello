package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFieldsLoanTermination implements RuleExecutor {

	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal id = (BigDecimal) ctx.getValue("/loan_account/ID");
		String status = (String) ctx.getValue("/loan_account/STATUS");
		List<Map<?, ?>> terminationDetails = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if (terminationDetails != null) {
			Iterator<Map<?, ?>> it = terminationDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				int chargecode_mst_id = 0;
				BigDecimal loanid = new BigDecimal(0);
				int chargecode = 0;
				int receivable_payable_flag = 0;

				for (Map.Entry entries : mapValues.entrySet()) {
					if (("CHARGECODE_MST_ID").equals(entries.getKey()))
						chargecode_mst_id = ((BigDecimal) entries.getValue()).intValue();
					if (("LOANID").equals(entries.getKey()))
						loanid = ((BigDecimal) entries.getValue());
					if (("CHARGECODE").equals(entries.getKey()))
						chargecode = ((BigDecimal) entries.getValue()).intValue();
					if (("RECEIVABLE_PAYABLE_FLAG").equals(entries.getKey()))
						receivable_payable_flag = ((BigDecimal) entries.getValue()).intValue();
				}
				if ((id == loanid) && "A".equalsIgnoreCase(status)) {
					if (chargecode_mst_id == 0) {
						logList.add("CHARGECODE_MST_ID of Loan Termination is null.");
						returnFlag = false;
					}
					if ((loanid == null) && loanid.compareTo(BigDecimal.ZERO) == 0) {
						logList.add("LOANID of Loan Termination is null.");
						returnFlag = false;
					}
					if (chargecode == 0) {
						logList.add("CHARGECODE of Loan Termination is null.");
						returnFlag = false;
					}
					if (receivable_payable_flag == 0) {
						logList.add("RECEIVABLE_PAYABLE_FLAG of Loan Termination is null.");
						returnFlag = false;
					}
				} else {
					logList.add(
							"Loanid of loan Repayment equals id of loan account and status of loan account is not exist.");
					returnFlag = false;
				}

			}
			if (returnFlag) {
				logList.add(
						"CHARGECODE_MST_ID of Loan Termination is not null,LOANID of Loan Termination is not null,CHARGECODE of Loan Termination is not null,RECEIVABLE_PAYABLE_FLAG of Loan Termination is not null.");
			}
		} else {
			returnFlag = false;
			logList.add("Loan Termination Details is not available.");

		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
