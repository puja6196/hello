package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandFieldsDisbursalDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> disbursaldetails = MVEL.eval("loan_account.?disbursal_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if (disbursaldetails != null) {

			Iterator<Map<?, ?>> itr = disbursaldetails.iterator();
			while (itr.hasNext()) {
				Map<String, String> mValues = (Map<String, String>) itr.next();
				BigDecimal id = new BigDecimal(0);
				String loan_account_no = null;
				BigDecimal currency_mst_id = new BigDecimal(0);
				BigDecimal loan_disbursal_amount = new BigDecimal(0);
				Date disbursal_date = null;
				BigDecimal disbursal_no = new BigDecimal(0);
				BigDecimal disbursal_rate = new BigDecimal(0);
				Date disbursal_txn_date = null;
				BigDecimal loan_id = new BigDecimal(0);
				String start_instllment_recovery = null;
				String disbursal_status = null;
				String transaction_type = null;
				for (Map.Entry entry : mValues.entrySet()) {
					if (("LOAN_ACCOUNT_NO").equals(entry.getKey()))
						loan_account_no = entry.getValue().toString();
					if (("CURRENCY_MST_ID").equals(entry.getKey()))
						currency_mst_id = (BigDecimal) entry.getValue();
					if (("DISBURSAL_AMT").equals(entry.getKey()))
						loan_disbursal_amount = (BigDecimal) entry.getValue();
					if (("DISBURSAL_DATE").equals(entry.getKey()))
						disbursal_date = (Date) entry.getValue();
					if (("DISBURSAL_NO").equals(entry.getKey()))
						disbursal_no = (BigDecimal) entry.getValue();
					if (("DISBURSAL_RATE").equals(entry.getKey()))
						disbursal_rate = (BigDecimal) entry.getValue();
					if (("DISBURSAL_TXN_DATE").equals(entry.getKey()))
						disbursal_txn_date = (Date) entry.getValue();
					if (("START_INSTALLMENT_RECOVERY").equals(entry.getKey()))
						start_instllment_recovery = entry.getValue().toString();
					if (("DISBURSAL_STATUS").equals(entry.getKey()))
						disbursal_status = entry.getValue().toString();
					if (("TRANSACTION_TYPE").equals(entry.getKey()))
						transaction_type = entry.getValue().toString();
					if (("ID").equals(entry.getKey()))
						id = (BigDecimal) entry.getValue();
					if (("LOANID").equals(entry.getKey()))
						loan_id = (BigDecimal) entry.getValue();
				}
				if ("A".equals(disbursal_status)) {
					if (id == null) {
						logList.add("Id of disbursal details is null for loan id :" + id);
						returnFlag = false;
					}
					if (loan_account_no == null) {
						logList.add("Loan account number of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
					if (currency_mst_id == null) {
						logList.add("Currency Mst Id of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
					if (loan_disbursal_amount == null) {
						logList.add("Loan Disbursal Amount of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
					if (disbursal_date == null) {
						logList.add("Loan Disbursal Date of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
					if (disbursal_no == null) {
						logList.add("Loan Disbursal Number of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
					if (disbursal_rate == null) {
						logList.add("Loan Disbursal Rate of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
					if (disbursal_txn_date == null) {
						logList.add("Disbursal Transation Date of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
					if (loan_id == null) {
						logList.add("Loan Id of disbursal details is null for loan id : " + id);
					}
					if (start_instllment_recovery == null) {
						logList.add("Start Installment Recovery of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
					if (disbursal_status == null) {
						logList.add("Disbursal Status of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
					if (transaction_type == null) {
						logList.add("Transaction Type of disbursal details is null for loan id : " + id);
						returnFlag = false;
					}
				}

			}
			if (returnFlag) {
				logList.add(
						"Id,Loan account number,Currency Mst Id,Loan Disbursal Amount,Loan Disbursal Date,Loan Disbursal Number,Loan Disbursal Rate,Disbursal Transation Date,Loan Id,Start Installment Recovery,Disbursal Status,Transaction Type are not null.");
				
			}

		} else {
			logList.add("Disbursal detials are not avilable.");
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
