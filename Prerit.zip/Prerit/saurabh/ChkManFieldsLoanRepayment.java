package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFieldsLoanRepayment implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal id = (BigDecimal) ctx.getValue("loan_account/ID");
		String status = (String) ctx.getValue("/Loan_account/STATUS");
		List<Map<?, ?>> repaymentDetails = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if (repaymentDetails != null) {
			Iterator<Map<?, ?>> it = repaymentDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				BigDecimal installment_amount = new BigDecimal(0);
				BigDecimal principal_component = new BigDecimal(0);
				BigDecimal interest_component = new BigDecimal(0);
				String advance_repay_flag = null;
				BigDecimal closing_principal = new BigDecimal(0);
				Date due_date = null;
				String emi_pemi_flag = null;
				int installment_number = 0;
				BigDecimal loanid = new BigDecimal(0);

				BigDecimal balance_principal = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("INSTALMENT_AMOUNT").equals(entries.getKey()))
						installment_amount = (BigDecimal) entries.getValue();
					if (("PRINCIPAL_COMPONENT").equals(entries.getKey()))
						principal_component = (BigDecimal) entries.getValue();
					if (("INTEREST_COMPONENT").equals(entries.getKey()))
						interest_component = (BigDecimal) entries.getValue();
					if (("ADVANCE_PREPAY_FLAG").equals(entries.getKey()))
						advance_repay_flag = entries.getValue().toString();
					if (("CLOSING_PRINCIPAL").equals(entries.getKey()))
						closing_principal = (BigDecimal) entries.getValue();
					if (("DUEDATE").equals(entries.getKey()))
						due_date = (Date) entries.getValue();
					if (("EMI_PEMI_FLAG").equals(entries.getKey()))
						emi_pemi_flag = entries.getValue().toString();
					if (("INSTALMENT_NUMBER").equals(entries.getKey()))
						installment_number = ((BigDecimal) entries.getValue()).intValue();
					if (("BALANCE_PRINCIPAL").equals(entries.getKey()))
						balance_principal = (BigDecimal) entries.getValue();
					if (("LOANID").equals(entries.getKey()))
						loanid = (BigDecimal) entries.getValue();

				}
				if ((loanid == id) && "A".equalsIgnoreCase(status)) {
					if ((installment_amount == null && installment_amount.compareTo(BigDecimal.ZERO) == 0)) {
						logList.add("INSTALLMENT_AMOUNT of Loan Repayment is null");
						returnFlag = false;
					}
					if ((principal_component == null && principal_component.compareTo(BigDecimal.ZERO) == 0)) {
						logList.add("PRINCIPAL_COMPONENT of Loan Repayment is null");

						returnFlag = false;
					}
					if ((interest_component == null && interest_component.compareTo(BigDecimal.ZERO) == 0)) {
						logList.add("INTREST_COMPONENT of Loan Repayment is null");
						returnFlag = false;

					}
					if ((advance_repay_flag == null)) {
						logList.add("ADVANCE_REPAY_FLAG of Loan Repayment is null");
						returnFlag = false;

					}
					if ((closing_principal == null && closing_principal.compareTo(BigDecimal.ZERO) == 0)) {
						logList.add("CLOSING_PRINCIPAL of Loan Repayment is null");
						returnFlag = false;

					}
					if ((due_date == null)) {
						logList.add("DUEDATE of Loan Repayment is null");
						returnFlag = false;

					}
					if ((emi_pemi_flag == null)) {
						logList.add("EMI_PEMI_FLAG of Loan Repayment is null");
						returnFlag = false;

					}
					if ((installment_number == 0)) {
						logList.add("INSTALLMENT_NUMBER of Loan Repayment is null");
						returnFlag = false;

					}
					if ((balance_principal == null && balance_principal.compareTo(BigDecimal.ZERO) == 0)) {
						logList.add("BALANCE_PRINCIPAL of Loan Repayment is null");
						returnFlag = false;

					}
				}else{
					logList.add(
							"CHARGECODE_MST_ID is not null,LOANID is not null,CHARGECODE is not null,RECEIVABLE_PAYABLE_FLAG is not null.");
				     returnFlag =false;
				}

			}
			if (returnFlag) {
				logList.add(
						"INSTALLMENT_AMOUNT of Loan Repayment is not  null,PRINCIPAL_COMPONENT of Loan Repayment is not null,INTREST_COMPONENT of Loan Repayment is not null,ADVANCE_REPAY_FLAG of Loan Repayment is not null,CLOSING_PRINCIPAL of Loan Repayment is not null,DUEDATE of Loan Repayment is not null,EMI_PEMI_FLAG of  Loan Repayment is not null,INSTALLMENT_NUMBER of Loan Repayment is not null,BALANCE_PRINCIPAL of Loan Repayment is not null.");

			}
		} else {
			returnFlag = false;
			logList.add("Loan Repayment Schedule not available.");

		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {

		return true;
	}

}
