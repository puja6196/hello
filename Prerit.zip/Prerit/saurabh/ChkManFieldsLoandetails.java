package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.JXPathContext;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFieldsLoandetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);

		int repay_policy_id = (int) ctx.getValue("/loan_account/REPAY_POLICY_ID", Integer.class);
		int schemeid = (int) ctx.getValue("/loan_account/SCHEMEID", Integer.class);
		int productid = (int) ctx.getValue("/loan_account/PRODUCTID", Integer.class);
		int currency_mst_id = (int) ctx.getValue("/loan_account/CURRENCY_MST_ID", Integer.class);
		int branchid = (int) ctx.getValue("/loan_account/BRANCHID", Integer.class);
		int pemi_tenure_inclusive_flag = (int) ctx.getValue("/loan_account/PEMI_TENURE_INCLUSIVE_FLAG", Integer.class);

		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;

		if (repay_policy_id == 0) {
			logList.add("REPAY_POLICY_ID of Loan account is null.");
			returnFlag = false;
		}
		if (schemeid == 0) {
			logList.add("SCHEME_ID of Loan account is null.");
			returnFlag = false;
		}
		if (productid == 0) {
			logList.add("PRODUCT_ID of Loan account is null.");
			returnFlag = false;
		}
		if (currency_mst_id == 0) {
			logList.add("CURRENCY_MST_ID of Loan account is null.");
			returnFlag = false;
		}
		if (branchid == 0) {
			logList.add("BRANCHID of  Loan account is null.");
			returnFlag = false;
		}
		if (pemi_tenure_inclusive_flag == 0) {
			logList.add("PEMI_TENURE_INCLUSIVE_FLAG of Loan account is null.");
			returnFlag = false;
		}

		if (returnFlag) {
			logList.add(
					"REPAY_POLICT_ID of Loan Account Is not null,SCHEMEID of Loan Account IS not null,PRODUCTID of Loan Account Is not null,CURRENCY_MST_ID of Loan Account Is not null,BRANCH_ID Loan Account Is not null,PEMI_TENURE_INCLUSIVE_FLAG of Loan Account Is not null.");
		}

		logger.setLog(logList);
		return returnFlag;

	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
