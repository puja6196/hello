package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManfieldsLoanReschedule implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		List<Map<?, ?>> rescheduledDetails = MVEL.eval("loan_account.?loan_reschedule_details", context, List.class);
		if (rescheduledDetails != null) {
			Iterator<Map<?, ?>> it = rescheduledDetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				int balance_installments = 0;
				int anchor_mst_id = 0;
				int change_type = 0;
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("BALANCE_INSTALLMENTS").equals(entries.getKey()))
						balance_installments = ((BigDecimal) entries.getValue()).intValue();
					if (("ANCHOR_MST_ID").equals(entries.getKey()))
						anchor_mst_id = ((BigDecimal) entries.getValue()).intValue();
					if (("CHANGE_TYPE").equals(entries.getKey()))
						change_type = ((BigDecimal) entries.getValue()).intValue();

				}
				if (balance_installments == 0) {
					logList.add("BALANCE_INSTALLMENTS of Loan Rescheduled is null.");

					returnFlag = false;
				}
				if (anchor_mst_id == 0) {
					logList.add("ANCHOR_MST_ID of Loan Rescheduled is null.");

					returnFlag = false;
				}
				if (change_type == 0) {
					logList.add("CHANGE_TYPE of Loan Rescheduled is null.");

					returnFlag = false;
				}

			}
			if (returnFlag) {
				logList.add(
						"BALANCE_INSTALLMENTS of Loan Rescheduled is not null,ANCHOR_MST_ID of Loan Rescheduled is not null,CHANGE_TYPE of Loan Rescheduled is not null.");

			}
		} else {
			returnFlag = false;
			logList.add("Loan Rescheduled Details not available.");

		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
