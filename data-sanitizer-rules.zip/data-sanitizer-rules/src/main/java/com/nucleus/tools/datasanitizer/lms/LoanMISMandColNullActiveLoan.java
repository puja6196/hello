package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanMISMandColNullActiveLoan implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		    JXPathContext ctx = JXPathContext.newContext(context);
		    Boolean resultFlag=true;		
		    List<String> logList = new ArrayList<>();
		    
			String loanAccNo = (String) ctx.getValue("/loan_account/loan_mis_details/LOAN_ACCOUNT_NO", String.class);
			
			BigDecimal loanId = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/LOANID", BigDecimal.class);
		
			BigDecimal frequencyId = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/FREQUENCY_ID", BigDecimal.class);
		
			String loanAccStatus = (String) ctx.getValue("/loan_account/STATUS", String.class);
	
		  if((loanAccStatus=="A")&&((loanAccNo==null)||((loanId==null)||(frequencyId==null))))
			
           {
	
             logList.add(" Data where mandatory columns are null for Active Loans in LMS_LOAN_MIS_DTL table for Loan ID:"+loanId);
             resultFlag=false;

           }
        if(resultFlag)
        {
        	
        	logList.add(" Mandatory columns are not null for Active Loans in LMS_LOAN_MIS_DTL table for Loan ID.");
        	
        	
        }
			
		logger.setLog(logList);	     
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
