package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAdvicesAllocationMismatch implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal id = (BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
		String status = (String) ctx.getValue("/loan_account/ID", String.class);
		
		   Boolean resultFlag=true;
		   List<Map<?,?>> adviceDetails = MVEL.eval("loan_account.?advice_details", context, List.class);

	         if(adviceDetails!=null)
	               {
						
		              Iterator<Map<?, ?>> it = adviceDetails.iterator();
		              while (it.hasNext())
							
		                 {
			                  Map<String,String> mapValues = (Map<String, String>) it.next();
			
			                 BigDecimal allocatedAmt=new BigDecimal(0);
			                 BigDecimal adviceDtlId=new BigDecimal(0);
			                 String adviceDtlStatus=null;
			                 BigDecimal chargeCode=new BigDecimal(0);
			                 
			
			                      for (Map.Entry entries : mapValues.entrySet())
			                            {
				                          if(("ALLOCATEDAMT").equals(entries.getKey()))
				                                 {
				                        	  allocatedAmt=(BigDecimal) entries.getValue();
					
				                                 }
				                          if(("ID").equals(entries.getKey()))
			                                 {
				                        	  adviceDtlId=(BigDecimal) entries.getValue();
				
			                                 }
				                          if(("STATUS").equals(entries.getKey()))
			                                 {
				                        	  adviceDtlStatus=(String) entries.getValue();
				
			                                 }
				                          if(("CHARGECODE").equals(entries.getKey()))
			                                 {
				                        	  chargeCode=(BigDecimal) entries.getValue();
				
			                                 }
			                          
					
			                            }
			                      if(){}   
			                      }
	               }
	         return false;
             
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
