package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanMISmismatchBilledTDSAmt implements RuleExecutor 
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{   JXPathContext ctx = JXPathContext.newContext(context);
		boolean resultFlag=true;
		 List<String> logList = new ArrayList<String>();
		 String loanId = (String) ctx.getValue("/loan_account/loan_mis_details/LOANID", String.class);
         String billedTDSAmt = (String) ctx.getValue("/loan_account/loan_mis_details/BILLED_TDS_AMT", String.class);
         List<Map<?,?>> adviceDetails = MVEL.eval("loan_account.?advice_details", context, List.class);
 		boolean returnFlag=true;
 		
 	
 		if(adviceDetails != null){
 			
 			Iterator<Map<?, ?>> it = adviceDetails.iterator();
 			while (it.hasNext()){
 				Map<String,String> mapValues = (Map<String, String>) it.next();
 				
 				BigDecimal tdsAmt=new BigDecimal(0);
 				String adviceLoanId=null;
 				String status=null;
 				for (Map.Entry entries : mapValues.entrySet())
 				{

 					if(("TDS_AMT").equals(entries.getKey()))
 						tdsAmt	 =(BigDecimal) entries.getValue();
 					if(("LOANID").equals(entries.getKey()))
 						adviceLoanId	 = (String) entries.getValue();
 						if(("STATUS").equals(entries.getKey()))
 						status =  (String) entries.getValue();
 				}
 				if((adviceLoanId==loanId)&&status=="A") { }
 						
 						
 				//}

		
	}return false;}

	@Override
	public boolean shouldExecute(RootObject arg0) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
