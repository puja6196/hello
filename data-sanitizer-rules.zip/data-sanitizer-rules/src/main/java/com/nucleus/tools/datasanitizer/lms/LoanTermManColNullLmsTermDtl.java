package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanTermManColNullLmsTermDtl implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		     JXPathContext ctx = JXPathContext.newContext(context);
		     Boolean resultFlag=true; 
             List<String> logList = new ArrayList<String>();
             List<Map<?,?>> terminationDetails = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
              
            	   BigDecimal loanAccId = (BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
	    	          String status = (String) ctx.getValue("/loan_account/STATUS", String.class);
	    	 
	    	           if(terminationDetails!=null)
	    	              {
	    		 
	                         Iterator<Map<?, ?>> it = terminationDetails.iterator();
	                           while (it.hasNext())
						
	                              {
		                                Map<String,String> mapValues = (Map<String, String>) it.next();
		
		                                BigDecimal loanId=new BigDecimal(0);
		                               
		
		                                  for (Map.Entry entries : mapValues.entrySet())
		                                     {
			                                           if(("ID").equals(entries.getKey()))
			                                              {
			                                	              loanId=(BigDecimal) entries.getValue();
				                                   
			                                              }
		                                     }
			                                           if((loanAccId.compareTo(loanId)==0)&&(status=="A")&&(loanId==null))
			                                              {
			                                    	  
			                                                   resultFlag=false;
			                                                   logList.add("Records where mandatory fields are null in  LMS_TERMINATION_DTL for Loan Id:"+loanId);
			                                      
			                                      
			                                               }
	                              }
			                                           if(resultFlag)
			                                           {
			                                        	   
			                                        	   
			                                        	   logList.add("Mandatory fields are not null in  LMS_TERMINATION_DTL.");
			                                        	   
			                                           }
			                                      
			           }
	    	                                          else
	    	                                               {
	    	        	                                        logList.add("Record not found in termination detail.");
	    	        	                                         resultFlag=false;
	    	        	   
	    	        	   
	    	                                               }
		                                 
			     
            	   
            	   
                               
	    	          
	    	           
               
              
               logger.setLog(logList);
               return resultFlag;
   
   
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
