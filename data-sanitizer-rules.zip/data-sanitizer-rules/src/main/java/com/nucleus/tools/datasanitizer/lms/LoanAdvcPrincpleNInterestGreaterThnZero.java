package com.nucleus.tools.datasanitizer.lms;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAdvcPrincpleNInterestGreaterThnZero implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	    {
	
		      Boolean resultFlag=true;
		      List<String> logList = new ArrayList<String>();
	     	  List<Map<?,?>> adviceDtl = MVEL.eval("loan_account.?advice_details", context, List.class);

		       if(adviceDtl!=null)
		          {
			         Iterator<Map<?, ?>> it = adviceDtl.iterator();
			           while (it.hasNext())
			            {
				          Map<String,String> mapValues = (Map<String, String>) it.next();				
				          BigDecimal chargeCode=new BigDecimal(0);
				          BigDecimal prinCompRecvd=new BigDecimal(0);
				          BigDecimal intCompRecvd=new BigDecimal(0);
				    
				               for (Map.Entry entries : mapValues.entrySet())
				                  {
					                   if(("ALLOCATEDAMT").equals(entries.getKey()))
					                       {
					        	              chargeCode=(BigDecimal) entries.getValue();
						          
						                   }
					                   if(("PRINCOMP_RECEIVED").equals(entries.getKey()))
					                       {
					        	               prinCompRecvd=(BigDecimal) entries.getValue();
						          
						                   }
					                   if(("INTCOMP_RECEIVED").equals(entries.getKey()))
					                       {
					        	               intCompRecvd=(BigDecimal) entries.getValue();
						          
						                   }
				                  }
					                   if((chargeCode.compareTo(new BigDecimal(9))!=0)&&((prinCompRecvd.compareTo(new BigDecimal(0))>0)||(intCompRecvd.compareTo())==1))
					                       {
					        	                resultFlag=false;
					        	                logList.add("Records where principal component received or interest component received is greater than zero for charge other than 9.");
					           
					                        }
			            }
					                  if(resultFlag)
					                   {
					                	  
					                	  logList.add("pending");
					                						                	   
					                	   
					                	   
					                	   
					                   }
				                 }
				               
			            }
		       else
		       {
		    	   
		    	   logList.add("No record found in adviceDtl.");
		    	   resultFlag=false;
		    	   
		    	   
		       }
		         
				       logger.setLog(logList);
				       return resultFlag;
				       
				       
	
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
