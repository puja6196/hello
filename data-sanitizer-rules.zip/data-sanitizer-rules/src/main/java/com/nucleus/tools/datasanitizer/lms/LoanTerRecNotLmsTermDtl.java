package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanTerRecNotLmsTermDtl implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		
		Boolean resultFlag=true;
		
		 List<Map<?,?>> termDtlDetails = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
		 
		 List<Map<?,?>> termHdrDetails = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		 List<String> logList = new ArrayList<String>();
	if(termDtlDetails!=null)
			{
			 Iterator<Map<?, ?>> itr = termDtlDetails.iterator();
             while (itr.hasNext())
					
                {
	                  Map<String,String> mapValues = (Map<String, String>) itr.next();
	
	                 BigDecimal terminationId=new BigDecimal(0);
	                 BigDecimal terHdrId=new BigDecimal(0);
	
	                      for (Map.Entry entries : mapValues.entrySet())
	                            {
		                          if(("TERMINATIONID").equals(entries.getKey()))
		                                 {
		                        	  terminationId=(BigDecimal) entries.getValue();
		                        	  
			
		                                 }
		                          if(("termination_hdr_details").equals(entries.getKey()))
                                          {
                                        	  termHdrDetails=(List<Map<?, ?>>) entries.getValue();
                                        	  

                                              Iterator<Map<?, ?>> it = termHdrDetails.iterator();
                                              while (it.hasNext()) 
                                                 {
                                                    Map<String, String> mapValue = (Map<String, String>) it.next();
                                              

                                            		for (Map.Entry entrie : mapValue.entrySet()) 
                                            		     {
                                            			if (("ID").equals(entries.getKey()))
                                            				terHdrId = (BigDecimal) entries.getValue();
                                            		     }   
                                                  }
                                              
                                        	  
                                          }
		                          
		                         
	                            }
	                      if(terminationId.compareTo(terHdrId)!=0)
                          {
                    	  
                    	  logList.add("Data which are not in  LMS_TERMINATION_DTL table for loanId:"+terHdrId);
                    	  resultFlag=false;
                    	  
                    	  
                    	  
                          }
                }
	                      if(resultFlag)
                          {
                        	 logList.add("No data available in Termination Details.");
                        	  
                        	  
                        	  
                          }
                
			}
	else
	{
		
		logList.add("No record found in Termination Details");
		resultFlag=false;
		
		
		
	}
		                         
                                        	  
                                        	  
                                        	  

                                          
	                            
		                      
			                  
		 
			

    logger.setLog(logList);
    return resultFlag;
		
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
