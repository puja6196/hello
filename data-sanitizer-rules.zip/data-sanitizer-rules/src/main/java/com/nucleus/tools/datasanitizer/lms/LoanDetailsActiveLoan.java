package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanDetailsActiveLoan implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		Boolean resultFlag=true;
		
		 List<Map<?,?>> loanMisDetails = MVEL.eval("loan_account.?loan_mis_details", context, List.class);
		
		 List<String> logList = new ArrayList<String>();
		
			String loanAccountNo = (String) ctx.getValue("/loan_account/LOAN_ACCOUNT_NO", String.class);
			if(loanMisDetails!=null)
			{
			 Iterator<Map<?, ?>> it = loanMisDetails.iterator();
             while (it.hasNext())
					
                {
	                  Map<String,String> mapValues = (Map<String, String>) it.next();
	
	                 Long loanAccountNoDtl=new Long(0);
	
	                      for (Map.Entry entries : mapValues.entrySet())
	                            {
		                          if(("LOAN_ACCOUNT_NO").equals(entries.getKey()))
		                                 {
		                        	  loanAccountNoDtl=(Long) entries.getValue();
		                        	  
			
		                                 }
	                            }
		                      
			                    if(loanAccountNoDtl.equals(loanAccountNo))
			                    {
			                    	
			                        resultFlag=false;
			                        logList.add("Active Loans having no data in LMS_LOAN_MIS_DTL Table.");
			                    
			                    }
			                   
			      }
		
             if(resultFlag)
             {
             	 logList.add("Active Loans having  data in LMS_LOAN_MIS_DTL Table.");
             	
             	
             }
			
	
			}
		
		               else
		                     {
			 
			                    logList.add("No record found in loan_Mis_Details.");
			                    resultFlag=false;
		 	 
		                      }
			
			
			
			
			
         
		
	 logger.setLog(logList);
	    return resultFlag;		


	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}

