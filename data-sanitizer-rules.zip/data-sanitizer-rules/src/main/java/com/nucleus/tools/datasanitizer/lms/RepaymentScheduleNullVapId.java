package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;
import org.springframework.retry.backoff.Sleeper;
import org.springframework.stereotype.Component;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

@Component
public class RepaymentScheduleNullVapId implements RuleExecutor {
	
	@Override
	public boolean execute(RootObject context,Logger logger) {
		
		List<Map<?,?>> repaymentDetails = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		System.out.println(repaymentDetails);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if(repaymentDetails != null){
		
		Iterator<Map<?, ?>> it = repaymentDetails.iterator();
		while (it.hasNext()){
			Map<String,String> mapValues = (Map<String, String>) it.next();
			int instNumber = 0;

			for (Map.Entry entries : mapValues.entrySet()){
				if(("VAPID").equals(entries.getKey())){
					if(entries.getValue() != null)
					{
						//do nothing
					}else{
						logList.add("VAP Id is null in the Repayment Schedule for Installment # "+instNumber);
						resultFlag = false;
						
					}
				}
					
			}
			
		} 
		
if (resultFlag){
	logList.add("VAP Id is not NULL in the Repayment Schedule.");
}

			logger.setLog(logList);
			return resultFlag;
		}
		
		return false;
	}


	
	@Override
	public boolean shouldExecute(RootObject context) {
		//JXPathContext ctx = JXPathContext.newContext(context);
		//String freezeFlag = (String)ctx.getValue("/loan_account/FREEZE_LOAN_FLAG", String.class);
		//return "N".equals(freezeFlag);
		return true;
	}

}
